import Certs.KitaevChannels.Proof
import Certs.KitaevChannels.Sanity
import Certs.KitaevSectors.Proof
import Certs.KitaevSectors.Sanity
import Certs.KitaevSectorSums.Proof
import Certs.KitaevSectorSums.Sanity
import LeanProof

/-!
# Quick check of the main results

After `lake build`, run `lake env lean Check.lean`. Each `example` succeeds only if `main` proves
*exactly* the stated `Claim`, and `#print axioms` must list only `propext`, `Classical.choice` and
`Quot.sound`. The full audit (source scan, build, type match, axioms, `leanchecker` replay) is
`python3 audit.py KitaevChannels`, `python3 audit.py KitaevSectors` and
`python3 audit.py KitaevSectorSums`.
-/

-- Theorem A (approximate factorization on a Hilbert space of any dimension)
example : Cert.KitaevChannels.Claim := Cert.KitaevChannels.main
#print axioms Cert.KitaevChannels.main
#print axioms Cert.KitaevChannels.hyps_satisfiable_infinite_dim

-- Theorem B, first sentence (infinitely many finite sectors)
example : Cert.KitaevSectors.Claim := Cert.KitaevSectors.main
#print axioms Cert.KitaevSectors.main
#print axioms Cert.KitaevSectors.hyps_satisfiable

-- Theorem B, extended version and channel statement
example : Cert.KitaevSectorSums.Claim := Cert.KitaevSectorSums.main
#print axioms Cert.KitaevSectorSums.main
#print axioms Cert.KitaevSectorSums.channel_hyps_satisfiable

-- Further results (Section 6 of lean_certificate.pdf)
#print axioms Kitaev.DeltaIso.symm
#print axioms Kitaev.Graded.graded_rigidity
