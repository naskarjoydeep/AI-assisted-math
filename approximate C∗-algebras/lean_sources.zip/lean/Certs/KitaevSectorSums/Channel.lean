import Certs.KitaevSectorSums.Ext
import Certs.KitaevChannels.Proof

/-!
# Block-diagonal channels

For `Φ = ⊕ₖ Φₖ(Pₖ · Pₖ)`, every map built from `Φ` by sums, products, powers and convergent
series acts on the diagonal blocks through the same expression in the `Φₖ`. In particular `Φ̃`
takes values in block-diagonal operators, its `k`-th diagonal block is `Φ̃ₖ(Pₖ x Pₖ)`, and
`(Im Φ̃, ⋆)` is the block-diagonal sum of the `(Im Φ̃ₖ, ⋆ₖ)`. Sector data `vₖ, Δₖ, Υₖ` as in
Theorem A then assemble into the data of Theorem B (`channel_sum`).
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]

theorem isBD_sub {x y : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) (hy : IsBD y) : IsBD (x - y) := by
  rw [sub_eq_add_neg, ← neg_one_smul ℂ y]
  exact isBD_add hx (isBD_smul _ hy)

section Compression

/-- `x ↦ Pₖ x Pₖ` is the compression `x ↦ ιₖ† x ιₖ` by the isometry `ιₖ : Hₖ → ⊕ₖ Hₖ`. -/
theorem blkL_eq_compress (k : ι) :
    (blkL k k : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (H k →L[ℂ] H k)) =
      compress (StarAlgHom.id ℂ (lp H 2 →L[ℂ] lp H 2)) (inj k) (inj k) := by
  ext x : 1
  rw [compress_apply, adjoint_inj, blkL_apply]
  rfl

theorem blk_cp (hS : StinespringThm) (k : ι) :
    IsCP (blkL k k : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (H k →L[ℂ] H k)) := by
  rw [blkL_eq_compress]
  exact compress_cp hS _ _

theorem blk_cb (hF : CPMapFacts) (hS : StinespringThm) (k : ι) :
    CBBound (blkL k k : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (H k →L[ℂ] H k)) 1 := by
  rw [blkL_eq_compress]
  exact (compress_cb_self hF hS _ _).mono (pow_le_one₀ (norm_nonneg _) (norm_inj_le k))

end Compression

section Sectors

/-- `T` acts on diagonal blocks through the `Tₖ`: `Pₖ T(x) Pₖ = Tₖ(Pₖ x Pₖ)` for all `x`. -/
def DiagCompat (T : (lp H 2 →L[ℂ] lp H 2) → (lp H 2 →L[ℂ] lp H 2))
    (Tk : ∀ k, (H k →L[ℂ] H k) → (H k →L[ℂ] H k)) : Prop :=
  ∀ k x, blk k k (T x) = Tk k (blk k k x)

/-- `T` takes values in block-diagonal operators. -/
def BDValued (T : (lp H 2 →L[ℂ] lp H 2) → (lp H 2 →L[ℂ] lp H 2)) : Prop := ∀ x, IsBD (T x)

/-- `T` maps block-diagonal operators to block-diagonal operators. -/
def BDPres (T : (lp H 2 →L[ℂ] lp H 2) → (lp H 2 →L[ℂ] lp H 2)) : Prop :=
  ∀ x, IsBD x → IsBD (T x)

variable {T : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)}
  {Tk : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k)}

theorem map_sector (h : DiagCompat T fun k => Tk k) {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2))
    (k : ι) : (X.map T).map (blkL k k) = (X.map (blkL k k)).map (Tk k) :=
  CStarMatrix.ext fun i j => h k (X i j)

/-- **Complete positivity is checked sector by sector.** -/
theorem cp_of_sectors (hS : StinespringThm) (hbd : BDValued T) (h : DiagCompat T fun k => Tk k)
    (hcp : ∀ k, IsCP (Tk k)) : IsCP T := fun n X hX =>
  nonneg_of_BD (X := X.map T) (fun i j => hbd (X i j)) fun k => by
    rw [map_sector h]
    exact hcp k n _ (blk_cp hS k n X hX)

/-- **cb-norms are checked sector by sector.** -/
theorem cb_of_sectors (hF : CPMapFacts) (hS : StinespringThm) (hbd : BDValued T)
    (h : DiagCompat T fun k => Tk k) {c : ℝ} (hc : 0 ≤ c) (hcb : ∀ k, CBBound (Tk k) c) :
    CBBound T c := fun n X =>
  norm_le_of_BD (X := X.map T) (fun i j => hbd (X i j)) (mul_nonneg hc (norm_nonneg X)) fun k => by
    rw [map_sector h]
    refine (hcb k n _).trans (mul_le_mul_of_nonneg_left ?_ hc)
    have := blk_cb hF hS k n X
    rwa [one_mul] at this

end Sectors

section Calculus

variable {T U : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)}
  {Tk Uk : ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)}

theorem dc_one : DiagCompat ⇑(1 : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2))
    fun k => ⇑(1 : (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)) := fun _ _ => rfl

theorem dc_mul (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) (hU : DiagCompat ⇑U fun k => ⇑(Uk k)) :
    DiagCompat ⇑(T * U) fun k => ⇑(Tk k * Uk k) := fun k x =>
  (hT k (U x)).trans (congrArg (Tk k) (hU k x))

theorem dc_add (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) (hU : DiagCompat ⇑U fun k => ⇑(Uk k)) :
    DiagCompat ⇑(T + U) fun k => ⇑(Tk k + Uk k) := fun k x =>
  (map_add (blkL k k) (T x) (U x)).trans (congrArg₂ (· + ·) (hT k x) (hU k x))

theorem dc_sub (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) (hU : DiagCompat ⇑U fun k => ⇑(Uk k)) :
    DiagCompat ⇑(T - U) fun k => ⇑(Tk k - Uk k) := fun k x =>
  (map_sub (blkL k k) (T x) (U x)).trans (congrArg₂ (· - ·) (hT k x) (hU k x))

theorem dc_smul (c : ℂ) (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) :
    DiagCompat ⇑(c • T) fun k => ⇑(c • Tk k) := fun k x =>
  (map_smul (blkL k k) c (T x)).trans (congrArg (c • ·) (hT k x))

theorem dc_nsmul (m : ℕ) (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) :
    DiagCompat ⇑(m • T) fun k => ⇑(m • Tk k) := fun k x =>
  (map_nsmul (blkL k k) m (T x)).trans (congrArg (m • ·) (hT k x))

set_option synthInstance.maxHeartbeats 200000 in
theorem dc_pow (hT : DiagCompat ⇑T fun k => ⇑(Tk k)) (j : ℕ) :
    DiagCompat ⇑(T ^ j) fun k => ⇑(Tk k ^ j) := by
  induction j with
  | zero => simp only [pow_zero]; exact dc_one
  | succ j ih => simp only [pow_succ]; exact dc_mul ih hT

/-- **Convergent series act on diagonal blocks termwise.** -/
theorem dc_tsum {a : ℕ → (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)}
    {ak : ℕ → ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)} (ha : Summable a)
    (hak : ∀ k, Summable fun j => ak j k) (h : ∀ j, DiagCompat ⇑(a j) fun k => ⇑(ak j k)) :
    DiagCompat ⇑(∑' j, a j) fun k => ⇑(∑' j, ak j k) := fun k x => by
  have e1 : blk k k ((∑' j, a j) x) = ∑' j, blk k k (a j x) :=
    ((blkCLM k k).comp (ContinuousLinearMap.apply ℂ (lp H 2 →L[ℂ] lp H 2) x)).map_tsum ha
  have e2 : (∑' j, ak j k) (blk k k x) = ∑' j, ak j k (blk k k x) :=
    (ContinuousLinearMap.apply ℂ (H k →L[ℂ] H k) (blk k k x)).map_tsum (hak k)
  rw [e1]
  exact (tsum_congr fun j => h j k x).trans e2.symm

theorem bdp_of_bdv (hT : BDValued ⇑T) : BDPres ⇑T := fun x _ => hT x

theorem bdp_one : BDPres ⇑(1 : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) :=
  fun _ hx => hx

theorem bdp_mul (hT : BDPres ⇑T) (hU : BDPres ⇑U) : BDPres ⇑(T * U) := fun x hx =>
  hT _ (hU x hx)

theorem bdp_sub (hT : BDPres ⇑T) (hU : BDPres ⇑U) : BDPres ⇑(T - U) := fun x hx =>
  isBD_sub (hT x hx) (hU x hx)

theorem bdp_smul (c : ℂ) (hT : BDPres ⇑T) : BDPres ⇑(c • T) := fun x hx => isBD_smul c (hT x hx)

set_option synthInstance.maxHeartbeats 200000 in
theorem bdp_pow (hT : BDPres ⇑T) (j : ℕ) : BDPres ⇑(T ^ j) := by
  induction j with
  | zero => simp only [pow_zero]; exact bdp_one
  | succ j ih => simp only [pow_succ]; exact bdp_mul ih hT

theorem bdv_mul_left (hT : BDValued ⇑T) : BDValued ⇑(T * U) := fun x => hT (U x)

theorem bdv_mul_right (hT : BDPres ⇑T) (hU : BDValued ⇑U) : BDValued ⇑(T * U) := fun x =>
  hT _ (hU x)

theorem bdv_add (hT : BDValued ⇑T) (hU : BDValued ⇑U) : BDValued ⇑(T + U) := fun x =>
  isBD_add (hT x) (hU x)

theorem bdv_sub (hT : BDValued ⇑T) (hU : BDValued ⇑U) : BDValued ⇑(T - U) := fun x =>
  isBD_sub (hT x) (hU x)

theorem bdv_smul (c : ℂ) (hT : BDValued ⇑T) : BDValued ⇑(c • T) := fun x => isBD_smul c (hT x)

theorem bdv_nsmul (m : ℕ) (hT : BDValued ⇑T) : BDValued ⇑(m • T) := by
  rw [← Nat.cast_smul_eq_nsmul ℂ m T]
  exact bdv_smul (m : ℂ) hT

theorem bdv_tsum {a : ℕ → (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)} (ha : Summable a)
    (h : ∀ j, BDValued ⇑(a j)) : BDValued ⇑(∑' j, a j) := fun x k l hkl => by
  have e : blk k l ((∑' j, a j) x) = ∑' j, blk k l (a j x) :=
    ((blkCLM k l).comp (ContinuousLinearMap.apply ℂ (lp H 2 →L[ℂ] lp H 2) x)).map_tsum ha
  rw [e]
  exact (tsum_congr fun j => h j x k l hkl).trans tsum_zero

end Calculus

/-- The series of `Φ̃` converges in the operator norm once `4η < 1`. -/
theorem summable_series {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
    {Φ : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)} {η : ℝ} (hcb : CBBound (Φ * Φ - Φ).toLinearMap η)
    (hη : 0 ≤ η) (h4 : 4 * η < 1) :
    Summable fun j => cbin j • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ j := by
  have hNcb := N_cb hcb
  have h4η : 0 ≤ 4 * η := by positivity
  have hterm : ∀ j, CBBound (cbin j • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ j).toLinearMap
      ((4 * η) ^ j) := fun j => by
    have h := (hNcb.pow h4η j).smul (cbin j)
    refine h.mono ?_
    have := norm_cbin_le j
    have : 0 ≤ (4 * η) ^ j := pow_nonneg h4η j
    nlinarith
  exact (CBBound.tsum (hasSum_geometric_of_lt_one h4η h4) (fun j => pow_nonneg h4η j) hterm).1

/-- `Φ̃ = (Φ - ½)·∑_{j ≥ 1} cⱼ Nʲ + Φ` with `N = 4(Φ - Φ²)`, on any Hilbert space. -/
theorem tilde_decomp {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
    (Φ : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K))
    (hS : Summable fun j => cbin j • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ j) :
    tildePhi Φ = (Φ - (1 / 2 : ℂ) • 1) *
      (∑' j, cbin (j + 1) • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ (j + 1)) + Φ := by
  rw [← sub_eq_iff_eq_add, tildePhi_eq, series_split _ hS]
  exact half_identity Φ _

theorem summable_shift {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K]
    [CompleteSpace K] (Φ : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K))
    (hS : Summable fun j => cbin j • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ j) :
    Summable fun j => cbin (j + 1) • (4 • (Φ - Φ * Φ) : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)) ^ (j + 1) :=
  (summable_nat_add_iff 1).2 hS

section Tilde

variable {Φk : ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)}
  {Φ : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)}

theorem dc_of_blockSum (hΦ : IsBlockSumMap Φ Φk) : DiagCompat ⇑Φ fun k => ⇑(Φk k) :=
  fun k x => (hΦ x).1 k

theorem bdv_of_blockSum (hΦ : IsBlockSumMap Φ Φk) : BDValued ⇑Φ := fun x => (hΦ x).2

/-- **`Φ̃` acts on the `k`-th diagonal block as `Φ̃ₖ`.** -/
theorem dc_tilde (hΦ : IsBlockSumMap Φ Φk)
    (hS : Summable fun j => cbin j •
      (4 • (Φ - Φ * Φ) : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) ^ j)
    (hSk : ∀ k, Summable fun j => cbin j •
      (4 • (Φk k - Φk k * Φk k) : (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)) ^ j) :
    DiagCompat ⇑(tildePhi Φ) fun k => ⇑(tildePhi (Φk k)) := by
  have hdc := dc_of_blockSum hΦ
  have hN := dc_nsmul 4 (dc_sub hdc (dc_mul hdc hdc))
  have hT := dc_tsum hS hSk fun j => dc_smul (cbin j) (dc_pow hN j)
  exact dc_smul (1 / 2 : ℂ) (dc_add dc_one (dc_mul (dc_sub (dc_nsmul 2 hdc) dc_one) hT))

set_option synthInstance.maxHeartbeats 200000 in
/-- **`Φ̃` takes values in block-diagonal operators**: `Φ̃ = (Φ - ½)·∑_{j ≥ 1} cⱼ Nʲ + Φ`, and
`N = 4(Φ - Φ²)` takes values in block-diagonal operators. -/
theorem bdv_tilde (hΦ : IsBlockSumMap Φ Φk)
    (hS : Summable fun j => cbin j •
      (4 • (Φ - Φ * Φ) : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) ^ j) :
    BDValued ⇑(tildePhi Φ) := by
  rw [tilde_decomp Φ hS]
  have hS' : Summable fun j => cbin (j + 1) •
      (4 • (Φ - Φ * Φ) : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) ^ (j + 1) :=
    summable_shift Φ hS
  have hΦv := bdv_of_blockSum hΦ
  have hNv : BDValued ⇑(4 • (Φ - Φ * Φ) : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) :=
    bdv_nsmul 4 (bdv_sub hΦv (bdv_mul_left hΦv))
  refine bdv_add (bdv_mul_right (bdp_sub (bdp_of_bdv hΦv) (bdp_smul _ bdp_one))
    (bdv_tsum hS' fun j => ?_)) hΦv
  rw [pow_succ]
  exact bdv_smul _ (bdv_mul_right (bdp_pow (bdp_of_bdv hNv) j) hNv)

/-- **`(Im Φ̃, ⋆)` is the block-diagonal sum of the `(Im Φ̃ₖ, ⋆ₖ)`.** -/
theorem blockSumAlg_tilde (hdc : DiagCompat ⇑(tildePhi Φ) fun k => ⇑(tildePhi (Φk k)))
    (hbd : BDValued ⇑(tildePhi Φ))
    (hfix : ∀ k, ∀ y ∈ LinearMap.range (tildePhi (Φk k)).toLinearMap, tildePhi (Φk k) y = y) :
    IsBlockSumAlg (LinearMap.range (tildePhi Φ).toLinearMap) (choiEffros Φ)
      (fun k => LinearMap.range (tildePhi (Φk k)).toLinearMap) (fun k => choiEffros (Φk k)) := by
  refine ⟨fun x => ⟨?_, ?_⟩, fun x _ y hy => ⟨fun k => ?_, fun k l hkl => hbd _ k l hkl⟩⟩
  · rintro ⟨z, rfl⟩
    exact ⟨hbd z, fun k => LinearMap.mem_range.2 ⟨blk k k z, (hdc k z).symm⟩⟩
  · rintro ⟨hx, hk⟩
    refine LinearMap.mem_range.2 ⟨x, op_ext fun k l => ?_⟩
    by_cases hkl : k = l
    · subst hkl
      exact (hdc k x).trans (hfix k _ (hk k))
    · exact (hbd x k l hkl).trans (hx k l hkl).symm
  · obtain ⟨z, rfl⟩ := LinearMap.mem_range.1 hy
    change blk k k (tildePhi Φ (x * tildePhi Φ z)) =
      tildePhi (Φk k) (blk k k x * blk k k (tildePhi Φ z))
    rw [hdc, blk_mul_of_BD (hbd z)]
    rfl

end Tilde

/-- A δ-isomorphism with `δ < 1` onto operators on a nonzero space has a nonzero domain. -/
theorem nontrivial_of_iso {B : Type} [CStarAlgebra B] [PartialOrder B] [StarOrderedRing B]
    {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K] [Nontrivial K]
    {δ : ℝ} {S : Submodule ℂ (K →L[ℂ] K)}
    {mul' : (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K)} {w : B →ₗ[ℂ] (K →L[ℂ] K)}
    (hw : IsExtDeltaIsoOntoGen δ S mul' w) (hδ : δ < 1) : Nontrivial B := by
  by_contra h
  rw [not_nontrivial_iff_subsingleton] at h
  have h1 : (1 : B) = 0 := Subsingleton.elim _ _
  have := hw.2.2.2.1
  rw [h1, map_zero, zero_sub, norm_neg, norm_one] at this
  linarith

end Cert.KitaevSectorSums
