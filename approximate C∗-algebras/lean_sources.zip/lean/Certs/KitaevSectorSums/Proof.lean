import Certs.KitaevSectorSums.ChannelSum

/-!
# The rest of Theorem B (proof)

* `claimExt`: apply Kitaev's Theorem 10.5 in every sector, then `extEps_sum` and `iso_sum`.
* `claimChannel`: apply Theorem A (`Cert.KitaevChannels.main`) and Kitaev's Theorem 12.1 in every
  sector, then `channel_sum`. The constants are `C = |C_A|` and
  `η₀ = min(η₀_A, η₁, 1/8, 1/(2(|C_A| + 1)))`, so that `C η < 1` and the series of every `Φ̃`
  converges.

In both cases the C\* algebra is `ℓ^∞` of the sector block algebras.
-/

open scoped ComplexOrder ENNReal

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

/-- An extended δ-isomorphism from a block algebra is one in the sense of `IsExtDeltaIsoOntoGen`. -/
theorem IsExtDeltaIsoOnto.gen {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K]
    [CompleteSpace K] {m : ℕ} {d : Fin m → ℕ} {δ : ℝ} {S : Submodule ℂ (K →L[ℂ] K)}
    {mul' : (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K)} {w : BlockAlg d →ₗ[ℂ] (K →L[ℂ] K)}
    (h : IsExtDeltaIsoOnto δ S mul' w) : IsExtDeltaIsoOntoGen δ S mul' w := h

/-- **Theorem B, first sentence, extended version.** -/
theorem claimExt : ClaimExt := by
  intro C₃ ε₃ h105 ε hε hε₃ hCε ι _ _ H _ _ _ _ Ak _ mulk A mul hAk hsum
  refine ⟨extEps_sum hsum hε hAk, ?_⟩
  have hex : ∀ k, ∃ (m : ℕ) (d : Fin m → ℕ) (v : BlockAlg d →ₗ[ℂ] (H k →L[ℂ] H k)),
      IsExtDeltaIsoOnto (C₃ * ε) (Ak k) (mulk k) v :=
    fun k => h105 (H k) (Ak k) (mulk k) ε hε hε₃ (hAk k)
  choose m d v hv using hex
  have hv' : ∀ k, IsExtDeltaIsoOntoGen (C₃ * ε) (Ak k) (mulk k) (v k) := fun k =>
    IsExtDeltaIsoOnto.gen (hv k)
  obtain ⟨k₀⟩ := ‹Nonempty ι›
  have hδ0 : 0 ≤ C₃ * ε := (norm_nonneg _).trans (hv k₀).2.2.2.1
  have : ∀ k, Nontrivial (BlockAlg (d k)) := fun k => nontrivial_of_iso (hv' k) hCε
  exact ⟨lp (fun k => BlockAlg (d k)) ∞, inferInstance, inferInstance, inferInstance,
    isoSum hv' hδ0, iso_sum hv' hδ0 hsum hCε⟩

/-- **Theorem B, second sentence.** -/
theorem claimChannel : ClaimChannel := by
  intro hF hS hD c₁ η₁ c₂ η₂ C₃ ε₃ hc₁ hη₁ hc₂ hη₂ hC₃ hε₃ h121 h126 h105
  obtain ⟨η₀A, CA, hη₀A, hA⟩ :=
    Cert.KitaevChannels.main hF hS hD c₁ η₁ c₂ η₂ C₃ ε₃ hc₁ hη₁ hc₂ hη₂ hC₃ hε₃ h121 h126 h105
  refine ⟨min η₀A (min η₁ (min (1 / 8) (1 / (2 * (|CA| + 1))))), |CA|,
    lt_min hη₀A (lt_min hη₁ (lt_min (by norm_num) (by positivity))), ?_⟩
  intro ι _ _ H _ _ _ _ Φk Φ η hucp hcb hη hηlt hfin hΦ
  have hηA : η < η₀A := hηlt.trans_le (min_le_left _ _)
  have hη1 : η < η₁ := hηlt.trans_le ((min_le_right _ _).trans (min_le_left _ _))
  have hη8 : η < 1 / 8 :=
    hηlt.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have hηC : η < 1 / (2 * (|CA| + 1)) :=
    hηlt.trans_le ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
  have hCη : |CA| * η < 1 := by
    have h := (lt_div_iff₀ (by positivity : (0 : ℝ) < 2 * (|CA| + 1))).1 hηC
    nlinarith [abs_nonneg CA]
  have hCA : CA * η ≤ |CA| * η := mul_le_mul_of_nonneg_right (le_abs_self CA) hη
  have hex := fun k => hA (H k) (Φk k) η (hucp k) (hcb k) hη hηA (hfin k)
  choose m d v Δ Υ hv hΔ hΥ hΔΥ hmul using hex
  have hv' : ∀ k, IsExtDeltaIsoOntoGen (|CA| * η) (LinearMap.range (tildePhi (Φk k)).toLinearMap)
      (choiEffros (Φk k)) (v k) := fun k =>
    IsExtDeltaIsoOnto.gen (IsExtDeltaIsoOnto.mono (hv k) hCA)
  have : ∀ k, Nontrivial (BlockAlg (d k)) := fun k => nontrivial_of_iso (hv' k) hCη
  exact channel_sum hF hS hΦ hucp hcb hη (by linarith)
    (fun k => h121 (H k) (Φk k) η (hucp k) (hcb k) hη hη1)
    (mul_nonneg (abs_nonneg _) hη) hCη hv' hΔ hΥ (fun k => (hΔΥ k).mono hCA)
    (fun k n X Y => (hmul k n X Y).trans (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right hCA (norm_nonneg X)) (norm_nonneg Y)))

/-- **The rest of Theorem B.** -/
theorem main : Claim := ⟨claimExt, claimChannel⟩

end Cert.KitaevSectorSums
