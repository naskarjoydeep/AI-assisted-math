import Certs.KitaevSectorSums.LpCStar

/-!
# Blocks of operators on a Hilbert direct sum, and block-diagonal operators

On `⊕ₖ Hₖ = lp H 2`: `inj k`, `prj k` are adjoint, an operator is determined by its blocks, products
and adjoints of block-diagonal operators are computed blockwise, and `a ↦ ⊕ₖ aₖ` is an injective
unital star homomorphism `ℓ^∞(B(Hₖ)) → B(⊕ₖ Hₖ)`.
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)]

theorem inj_apply (k : ι) (a : H k) : inj k a = lp.single 2 k a := rfl

theorem prj_apply (k : ι) (f : lp H 2) : prj k f = f k := rfl

theorem prj_inj_self (k : ι) (a : H k) : prj k (inj k a) = a := lp.single_apply_self 2 k a

theorem prj_inj_ne {k l : ι} (h : k ≠ l) (a : H l) : prj k (inj l a) = 0 :=
  lp.single_apply_ne 2 l a h

theorem norm_inj_le (k : ι) : ‖(inj k : H k →L[ℂ] lp H 2)‖ ≤ 1 :=
  ContinuousLinearMap.opNorm_le_bound _ zero_le_one fun a => by
    rw [inj_apply, lp.norm_single (by norm_num), one_mul]

theorem norm_prj_le (k : ι) : ‖(prj k : lp H 2 →L[ℂ] H k)‖ ≤ 1 :=
  ContinuousLinearMap.opNorm_le_bound _ zero_le_one fun f => by
    rw [prj_apply, one_mul]; exact lp.norm_apply_le_norm two_ne_zero f k

theorem adjoint_inj (k : ι) : ContinuousLinearMap.adjoint (inj k : H k →L[ℂ] lp H 2) = prj k := by
  refine ContinuousLinearMap.ext fun f => ext_inner_right ℂ fun a => ?_
  rw [ContinuousLinearMap.adjoint_inner_left, prj_apply, inj_apply, lp.inner_single_right]

theorem blk_apply (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) (a : H l) :
    blk k l x a = x (lp.single 2 l a) k := rfl

theorem norm_blk_le (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) : ‖blk k l x‖ ≤ ‖x‖ := by
  unfold blk
  calc ‖prj k ∘L x ∘L inj l‖ ≤ ‖(prj k : lp H 2 →L[ℂ] H k)‖ * (‖x‖ * ‖(inj l : H l →L[ℂ] lp H 2)‖) :=
        (ContinuousLinearMap.opNorm_comp_le _ _).trans
          (mul_le_mul_of_nonneg_left (ContinuousLinearMap.opNorm_comp_le _ _) (norm_nonneg _))
    _ ≤ 1 * (‖x‖ * 1) := by
        gcongr
        · exact norm_prj_le k
        · exact norm_inj_le l
    _ = ‖x‖ := by ring

/-- The block as a linear map in `x`. -/
def blkL (k l : ι) : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (H l →L[ℂ] H k) where
  toFun := blk k l
  map_add' x y := by simp [blk, ContinuousLinearMap.add_comp, ContinuousLinearMap.comp_add]
  map_smul' c x := by simp [blk, ContinuousLinearMap.smul_comp]

theorem blkL_apply (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) : blkL k l x = blk k l x := rfl

/-- The block as a continuous linear map in `x`. -/
def blkCLM (k l : ι) : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (H l →L[ℂ] H k) :=
  (blkL k l).mkContinuous 1 fun x => by rw [one_mul]; exact norm_blk_le k l x

theorem blkCLM_apply (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) : blkCLM k l x = blk k l x := rfl

/-- **An operator on `⊕ₖ Hₖ` is determined by its blocks.** -/
theorem op_ext {x y : lp H 2 →L[ℂ] lp H 2} (h : ∀ k l, blk k l x = blk k l y) : x = y := by
  refine ContinuousLinearMap.ext fun ξ => lp.ext (funext fun k => ?_)
  have hs := lp.hasSum_single (E := H) (p := 2) (by norm_num) ξ
  have hx := hs.mapL ((prj k).comp x)
  have hy := hs.mapL ((prj k).comp y)
  have e : (fun l => ((prj k).comp x) (lp.single 2 l (ξ l))) =
      fun l => ((prj k).comp y) (lp.single 2 l (ξ l)) := funext fun l => by
    have := congrArg (fun T : H l →L[ℂ] H k => T (ξ l)) (h k l)
    simpa [blk, inj_apply] using this
  rw [e] at hx
  exact (hy.unique hx).symm

/-- `x` is block-diagonal: all off-diagonal blocks vanish. -/
def IsBD (x : lp H 2 →L[ℂ] lp H 2) : Prop := ∀ k l, k ≠ l → blk k l x = 0

/-- A block-diagonal `x` maps the `l`-th summand into itself. -/
theorem comp_inj_of_BD {x : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) (l : ι) :
    x ∘L inj l = inj l ∘L blk l l x := by
  refine ContinuousLinearMap.ext fun a => lp.ext (funext fun k => ?_)
  by_cases hkl : k = l
  · subst hkl
    change prj k (x (inj k a)) = prj k (inj k (blk k k x a))
    rw [prj_inj_self]; rfl
  · change prj k (x (inj l a)) = prj k (inj l (blk l l x a))
    rw [prj_inj_ne hkl]
    exact congrArg (fun T : H l →L[ℂ] H k => T a) (hx k l hkl)

theorem blk_mul_of_BD {x y : lp H 2 →L[ℂ] lp H 2} (hy : IsBD y) (k l : ι) :
    blk k l (x * y) = blk k l x ∘L blk l l y := by
  change prj k ∘L (x ∘L y) ∘L inj l = (prj k ∘L x ∘L inj l) ∘L blk l l y
  rw [ContinuousLinearMap.comp_assoc, comp_inj_of_BD hy l]; rfl

theorem isBD_mul {x y : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) (hy : IsBD y) : IsBD (x * y) :=
  fun k l hkl => by rw [blk_mul_of_BD hy, hx k l hkl, ContinuousLinearMap.zero_comp]

theorem blk_star (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) :
    blk k l (star x) = ContinuousLinearMap.adjoint (blk l k x) := by
  have hp : ContinuousLinearMap.adjoint (prj l : lp H 2 →L[ℂ] H l) = inj l := by
    rw [← adjoint_inj l, ContinuousLinearMap.adjoint_adjoint]
  simp only [blk, ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.adjoint_comp, adjoint_inj,
    hp, ContinuousLinearMap.comp_assoc]

theorem isBD_star {x : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) : IsBD (star x) :=
  fun k l hkl => by rw [blk_star, hx l k (Ne.symm hkl), map_zero]

theorem blk_one_self (k : ι) : blk k k (1 : lp H 2 →L[ℂ] lp H 2) = 1 :=
  ContinuousLinearMap.ext fun a => prj_inj_self k a

theorem isBD_one : IsBD (1 : lp H 2 →L[ℂ] lp H 2) :=
  fun k l hkl => ContinuousLinearMap.ext fun a => prj_inj_ne hkl a

theorem isBD_add {x y : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) (hy : IsBD y) : IsBD (x + y) :=
  fun k l hkl => by rw [← blkL_apply, map_add, blkL_apply, blkL_apply, hx k l hkl, hy k l hkl, add_zero]

theorem isBD_smul (c : ℂ) {x : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) : IsBD (c • x) :=
  fun k l hkl => by rw [← blkL_apply, map_smul, blkL_apply, hx k l hkl, smul_zero]

theorem isBD_zero : IsBD (0 : lp H 2 →L[ℂ] lp H 2) :=
  fun k l _ => by rw [← blkL_apply, map_zero]

section BlockDiag

variable [∀ k, Nontrivial (H k)]

/-- The family of diagonal blocks of `x`, as an element of `ℓ^∞(B(Hₖ))`. -/
def diagBlocks (x : lp H 2 →L[ℂ] lp H 2) : lp (fun k => H k →L[ℂ] H k) ∞ :=
  ⟨fun k => blk k k x, memℓp_infty ⟨‖x‖, by rintro _ ⟨k, rfl⟩; exact norm_blk_le k k x⟩⟩

theorem diagBlocks_apply (x : lp H 2 →L[ℂ] lp H 2) (k : ι) : diagBlocks x k = blk k k x := rfl

theorem memℓp_bd (a : lp (fun k => H k →L[ℂ] H k) ∞) (ξ : lp H 2) :
    Memℓp (fun k => a k (ξ k)) 2 := by
  have hξ := (lp.memℓp ξ).summable (by norm_num : (0 : ℝ) < (2 : ℝ≥0∞).toReal)
  refine memℓp_gen (Summable.of_nonneg_of_le (fun k => by positivity) (fun k => ?_)
    (hξ.mul_left (‖a‖ ^ (2 : ℝ≥0∞).toReal)))
  have h1 : ‖a k (ξ k)‖ ≤ ‖a‖ * ‖ξ k‖ :=
    ((a k).le_opNorm (ξ k)).trans (mul_le_mul_of_nonneg_right
      (lp.norm_apply_le_norm ENNReal.top_ne_zero a k) (norm_nonneg _))
  rw [← Real.mul_rpow (norm_nonneg _) (norm_nonneg _)]
  exact Real.rpow_le_rpow (norm_nonneg _) h1 (by norm_num)

/-- The block-diagonal operator `⊕ₖ aₖ`, as a linear map on `⊕ₖ Hₖ`. -/
def bdLin (a : lp (fun k => H k →L[ℂ] H k) ∞) : lp H 2 →ₗ[ℂ] lp H 2 where
  toFun ξ := ⟨fun k => a k (ξ k), memℓp_bd a ξ⟩
  map_add' ξ ζ := lp.ext (funext fun k => by
    change a k ((ξ + ζ : lp H 2) k) = a k (ξ k) + a k (ζ k)
    rw [lp.coeFn_add, Pi.add_apply, map_add])
  map_smul' c ξ := lp.ext (funext fun k => by
    change a k ((c • ξ : lp H 2) k) = c • a k (ξ k)
    rw [lp.coeFn_smul, Pi.smul_apply, map_smul])

theorem norm_bdLin_le (a : lp (fun k => H k →L[ℂ] H k) ∞) (ξ : lp H 2) :
    ‖bdLin a ξ‖ ≤ ‖a‖ * ‖ξ‖ := by
  have hp : (0 : ℝ) < (2 : ℝ≥0∞).toReal := by norm_num
  refine lp.norm_le_of_tsum_le hp (by positivity) ?_
  have hξ := (lp.memℓp ξ).summable hp
  calc ∑' k, ‖(bdLin a ξ) k‖ ^ (2 : ℝ≥0∞).toReal
      ≤ ∑' k, ‖a‖ ^ (2 : ℝ≥0∞).toReal * ‖ξ k‖ ^ (2 : ℝ≥0∞).toReal := by
        refine Summable.tsum_le_tsum (fun k => ?_) ((lp.memℓp (bdLin a ξ)).summable hp)
          (hξ.mul_left _)
        have h1 : ‖a k (ξ k)‖ ≤ ‖a‖ * ‖ξ k‖ :=
          ((a k).le_opNorm (ξ k)).trans (mul_le_mul_of_nonneg_right
            (lp.norm_apply_le_norm ENNReal.top_ne_zero a k) (norm_nonneg _))
        rw [← Real.mul_rpow (norm_nonneg _) (norm_nonneg _)]
        exact Real.rpow_le_rpow (norm_nonneg _) h1 (by norm_num)
    _ = ‖a‖ ^ (2 : ℝ≥0∞).toReal * ‖ξ‖ ^ (2 : ℝ≥0∞).toReal := by
        rw [tsum_mul_left, lp.norm_rpow_eq_tsum hp]
    _ = (‖a‖ * ‖ξ‖) ^ (2 : ℝ≥0∞).toReal := (Real.mul_rpow (norm_nonneg _) (norm_nonneg _)).symm

/-- The block-diagonal operator `⊕ₖ aₖ`. -/
def bdOp (a : lp (fun k => H k →L[ℂ] H k) ∞) : lp H 2 →L[ℂ] lp H 2 :=
  (bdLin a).mkContinuous ‖a‖ (norm_bdLin_le a)

theorem bdOp_apply (a : lp (fun k => H k →L[ℂ] H k) ∞) (ξ : lp H 2) (k : ι) :
    bdOp a ξ k = a k (ξ k) := rfl

theorem blk_bdOp_self (a : lp (fun k => H k →L[ℂ] H k) ∞) (k : ι) : blk k k (bdOp a) = a k :=
  ContinuousLinearMap.ext fun b => by
    rw [blk_apply, bdOp_apply, lp.single_apply_self]

theorem blk_bdOp_ne (a : lp (fun k => H k →L[ℂ] H k) ∞) {k l : ι} (h : k ≠ l) :
    blk k l (bdOp a) = 0 :=
  ContinuousLinearMap.ext fun b => by
    rw [blk_apply, bdOp_apply, lp.single_apply_ne 2 l b h, map_zero]; rfl

theorem isBD_bdOp (a : lp (fun k => H k →L[ℂ] H k) ∞) : IsBD (bdOp a) :=
  fun _ _ h => blk_bdOp_ne a h

/-- A block-diagonal operator is `⊕ₖ` of its diagonal blocks. -/
theorem bdOp_diagBlocks {x : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) : bdOp (diagBlocks x) = x := by
  refine op_ext fun k l => ?_
  by_cases hkl : k = l
  · subst hkl; rw [blk_bdOp_self, diagBlocks_apply]
  · rw [blk_bdOp_ne _ hkl, hx k l hkl]

/-- `a ↦ ⊕ₖ aₖ` as a unital star algebra homomorphism `ℓ^∞(B(Hₖ)) → B(⊕ₖ Hₖ)`. -/
def bdHom : lp (fun k => H k →L[ℂ] H k) ∞ →⋆ₐ[ℂ] (lp H 2 →L[ℂ] lp H 2) where
  toFun := bdOp
  map_one' := op_ext fun k l => by
    by_cases hkl : k = l
    · subst hkl; rw [blk_bdOp_self, lp.infty_coeFn_one, Pi.one_apply, blk_one_self]
    · rw [blk_bdOp_ne _ hkl, isBD_one k l hkl]
  map_mul' a b := op_ext fun k l => by
    rw [blk_mul_of_BD (isBD_bdOp b)]
    by_cases hkl : k = l
    · subst hkl; rw [blk_bdOp_self, blk_bdOp_self, blk_bdOp_self, lp.infty_coeFn_mul]; rfl
    · rw [blk_bdOp_ne _ hkl, blk_bdOp_ne _ hkl, ContinuousLinearMap.zero_comp]
  map_zero' := ContinuousLinearMap.ext fun ξ => lp.ext (funext fun k => by
    rw [bdOp_apply, lp.coeFn_zero, Pi.zero_apply, ContinuousLinearMap.zero_apply,
      ContinuousLinearMap.zero_apply, lp.coeFn_zero, Pi.zero_apply])
  map_add' a b := ContinuousLinearMap.ext fun ξ => lp.ext (funext fun k => by
    rw [ContinuousLinearMap.add_apply, lp.coeFn_add, Pi.add_apply, bdOp_apply, bdOp_apply, bdOp_apply,
      lp.coeFn_add, Pi.add_apply, ContinuousLinearMap.add_apply])
  commutes' c := op_ext fun k l => by
    rw [Algebra.algebraMap_eq_smul_one, Algebra.algebraMap_eq_smul_one, ← blkL_apply (x := c • 1),
      map_smul, blkL_apply]
    by_cases hkl : k = l
    · subst hkl
      rw [blk_bdOp_self, blk_one_self, lp.coeFn_smul, lp.infty_coeFn_one]; rfl
    · rw [blk_bdOp_ne _ hkl, isBD_one k l hkl, smul_zero]
  map_star' a := op_ext fun k l => by
    rw [blk_star]
    by_cases hkl : k = l
    · subst hkl; rw [blk_bdOp_self, blk_bdOp_self, lp.star_apply, ContinuousLinearMap.star_eq_adjoint]
    · rw [blk_bdOp_ne _ hkl, blk_bdOp_ne _ (Ne.symm hkl), map_zero]

theorem bdHom_apply (a : lp (fun k => H k →L[ℂ] H k) ∞) : bdHom a = bdOp a := rfl

theorem bdHom_injective : Function.Injective (bdHom (H := H)) := by
  intro a b h
  refine lp.ext (funext fun k => ?_)
  have := congrArg (blk k k) h
  rwa [bdHom_apply, bdHom_apply, blk_bdOp_self, blk_bdOp_self] at this

end BlockDiag

end Cert.KitaevSectorSums
