import Certs.KitaevSectorSums.HSum

/-!
# Matrices with block-diagonal entries

For `X ∈ Mₙ(B(⊕ₖ Hₖ))` whose entries are block-diagonal, `‖X‖` is the supremum over `k` of the
norms of the sector matrices `Xᵏ = (blk k k (X i j))ᵢⱼ ∈ Mₙ(B(Hₖ))`, and `X ≥ 0` iff every
`Xᵏ ≥ 0`. Both follow from `X = (lift X).map ⊕`, with `⊕ : ℓ^∞(B(Hₖ)) → B(⊕ₖ Hₖ)` an injective
star homomorphism of C\*-algebras.
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]

/-- All entries of `X` are block-diagonal. -/
def IsBDMat {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2)) : Prop := ∀ i j, IsBD (X i j)

/-- The lift of a matrix to `Mₙ(ℓ^∞(B(Hₖ)))`, entrywise diagonal blocks. -/
def liftMat {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2)) : Mat n (lp (fun k => H k →L[ℂ] H k) ∞) :=
  CStarMatrix.ofMatrix fun i j => diagBlocks (X i j)

theorem liftMat_map_bd {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) :
    (liftMat X).map (bdHom (H := H)) = X :=
  CStarMatrix.ext fun i j => bdOp_diagBlocks (hX i j)

theorem liftMat_map_eval {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2)) (k : ι) :
    (liftMat X).map (evalHom (A := fun k => H k →L[ℂ] H k) k) = X.map (blkL k k) :=
  CStarMatrix.ext fun i j => rfl

theorem matHom_bd_injective (n : ℕ) : Function.Injective (matHom n (bdHom (H := H))) := by
  intro Y Z h
  refine CStarMatrix.ext fun i j => bdHom_injective ?_
  exact congrArg (fun W : Mat n (lp H 2 →L[ℂ] lp H 2) => W i j) h

theorem norm_liftMat {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) :
    ‖liftMat X‖ = ‖X‖ := by
  conv_rhs => rw [← liftMat_map_bd hX]
  exact (NonUnitalStarAlgHom.norm_map (matHom n (bdHom (H := H))) (matHom_bd_injective n) _).symm

/-- **The norm of a matrix with block-diagonal entries is the supremum of its sector norms.** -/
theorem norm_le_of_BD {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) {c : ℝ}
    (hc : 0 ≤ c) (h : ∀ k, ‖X.map (blkL k k)‖ ≤ c) : ‖X‖ ≤ c := by
  rw [← norm_liftMat hX]
  exact norm_le_of_sectors _ hc fun k => by rw [liftMat_map_eval]; exact h k

theorem norm_sector_le {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) (k : ι) :
    ‖X.map (blkL k k)‖ ≤ ‖X‖ := by
  rw [← liftMat_map_eval, ← norm_liftMat hX]
  exact norm_map_evalHom_le _ k

/-- **A matrix with block-diagonal entries is positive if every sector is.** -/
theorem nonneg_of_BD {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X)
    (h : ∀ k, 0 ≤ X.map (blkL k k)) : 0 ≤ X := by
  have hl : 0 ≤ liftMat X := nonneg_of_sectors _ fun k => by rw [liftMat_map_eval]; exact h k
  have := OrderHomClass.mono (matHom n (bdHom (H := H))) hl
  rw [map_zero] at this
  rw [← liftMat_map_bd hX]
  exact this

theorem isBDMat_mul {n : ℕ} {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) (hY : IsBDMat Y) :
    IsBDMat (X * Y) := by
  intro i j
  rw [CStarMatrix.mul_apply]
  intro k l hkl
  rw [← blkL_apply, map_sum]
  exact Finset.sum_eq_zero fun m _ => by rw [blkL_apply, blk_mul_of_BD (hY m j), hX i m k l hkl,
    ContinuousLinearMap.zero_comp]

theorem map_blk_mul {n : ℕ} {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hY : IsBDMat Y) (k : ι) :
    (X * Y).map (blkL k k) = X.map (blkL k k) * Y.map (blkL k k) := by
  refine CStarMatrix.ext fun i j => ?_
  rw [amp_apply, CStarMatrix.mul_apply, CStarMatrix.mul_apply, map_sum]
  exact Finset.sum_congr rfl fun m _ => by rw [blkL_apply, blk_mul_of_BD (hY m j)]; rfl

theorem map_blk_star {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2)) (k : ι) :
    (star X).map (blkL k k) = star (X.map (blkL k k)) := by
  refine CStarMatrix.ext fun i j => ?_
  rw [amp_apply, CStarMatrix.star_apply, CStarMatrix.star_apply, amp_apply, blkL_apply, blkL_apply,
    blk_star, ContinuousLinearMap.star_eq_adjoint]

theorem isBDMat_star {n : ℕ} {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) :
    IsBDMat (star X) := fun i j => by rw [CStarMatrix.star_apply]; exact isBD_star (hX j i)

theorem isBDMat_sub {n : ℕ} {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : IsBDMat X) (hY : IsBDMat Y) :
    IsBDMat (X - Y) := fun i j => by
  change IsBD (X i j - Y i j)
  rw [sub_eq_add_neg, ← neg_one_smul ℂ (Y i j)]
  exact isBD_add (hX i j) (isBD_smul _ (hY i j))

end Cert.KitaevSectorSums
