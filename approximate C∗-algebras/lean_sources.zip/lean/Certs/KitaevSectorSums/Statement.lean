import Certs.KitaevChannels.Statement
import Mathlib.Analysis.InnerProductSpace.l2Space

/-!
# Theorem B, the parts not covered by `KitaevSectors` (statement)

Source: the paper *Kitaev's ε-C\* rigidity beyond finite dimensions* (J. Naskar and Claude),
Theorem B. The certificate `KitaevSectors` proves its first sentence for ε-C\* algebras in the sense
of Kitaev's Definition 2.1. This certificate proves the rest.

* `ClaimExt` is the first sentence for *extended* ε-C\* algebras (Kitaev §10). As in the
  certificate of Theorem A, an extended ε-C\* algebra is realized as a subspace `Aₖ ⊆ B(Hₖ)` with a
  bilinear product `mulₖ`, with the matrix norms of `Mₙ(B(Hₖ))`. The ℓ^∞-direct sum is realized
  on the Hilbert direct sum `⊕ₖ Hₖ` (`lp H 2`): it consists of the block-diagonal operators whose
  `k`-th diagonal block lies in `Aₖ`, with the blockwise product. Assumes Kitaev's Theorem 10.5.
* `ClaimChannel` is the second sentence. For a block-diagonal channel `Φ = ⊕ₖ Φₖ(Pₖ · Pₖ)` on
  `B(⊕ₖ Hₖ)` whose sectors satisfy the hypotheses of Theorem A, `Φ` is UCP with
  `‖Φ² - Φ‖_cb ≤ η`, and the conclusions of Theorem A hold with a C\* algebra in place of the
  finite-dimensional block algebra. Assumes what Theorem A assumes.

Kitaev's results enter only as the named hypotheses `Kitaev12_1`, `Kitaev12_6`, `Kitaev10_5`
(defined in `Certs.KitaevChannels.Statement`), never as axioms.
-/

open scoped ComplexOrder ENNReal

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

section Blocks

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)]

/-- The inclusion `Hₖ → ⊕ₖ Hₖ` of the `k`-th summand of the Hilbert direct sum `lp H 2`. -/
def inj (k : ι) : H k →L[ℂ] lp H 2 := lp.singleContinuousLinearMap ℂ H 2 k

/-- The projection `⊕ₖ Hₖ → Hₖ` onto the `k`-th summand. -/
def prj (k : ι) : lp H 2 →L[ℂ] H k := lp.evalCLM ℂ H 2 k

/-- The `(k, l)` block `Pₖ x Pₗ` of an operator `x` on `⊕ₖ Hₖ`, as an operator `Hₗ → Hₖ`. -/
def blk (k l : ι) (x : lp H 2 →L[ℂ] lp H 2) : H l →L[ℂ] H k := prj k ∘L x ∘L inj l

/-- `Φ` is the block-diagonal channel `x ↦ ⊕ₖ Φₖ(Pₖ x Pₖ)`: every off-diagonal block of `Φ(x)`
vanishes, and the `k`-th diagonal block of `Φ(x)` is `Φₖ` applied to the `k`-th diagonal block
of `x`. -/
def IsBlockSumMap (Φ : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2))
    (Φk : ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)) : Prop :=
  ∀ x, (∀ k, blk k k (Φ x) = Φk k (blk k k x)) ∧ ∀ k l, k ≠ l → blk k l (Φ x) = 0

/-- `(A, mul)` is the ℓ^∞-direct sum of the `(Aₖ, mulₖ)`, realized block-diagonally: `A` is the
set of bounded operators on `⊕ₖ Hₖ` with vanishing off-diagonal blocks and `k`-th diagonal block
in `Aₖ`, and for `x, y ∈ A` the product `mul x y` is block-diagonal with `k`-th block
`mulₖ xₖ yₖ`. -/
def IsBlockSumAlg (A : Submodule ℂ (lp H 2 →L[ℂ] lp H 2))
    (mul : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2))
    (Ak : ∀ k, Submodule ℂ (H k →L[ℂ] H k))
    (mulk : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k)) : Prop :=
  (∀ x, x ∈ A ↔ (∀ k l, k ≠ l → blk k l x = 0) ∧ ∀ k, blk k k x ∈ Ak k) ∧
  ∀ x ∈ A, ∀ y ∈ A, (∀ k, blk k k (mul x y) = mulk k (blk k k x) (blk k k y)) ∧
    ∀ k l, k ≠ l → blk k l (mul x y) = 0

end Blocks

/-- Kitaev's extended δ-isomorphism (§10) from an arbitrary C\* algebra `B` onto `(A, mul)`:
the same conditions as `IsExtDeltaIsoOnto`, whose domain is a finite block algebra. -/
def IsExtDeltaIsoOntoGen {B : Type} [CStarAlgebra B] [PartialOrder B] [StarOrderedRing B]
    {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
    (δ : ℝ) (A : Submodule ℂ (K →L[ℂ] K)) (mul : (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K))
    (v : B →ₗ[ℂ] (K →L[ℂ] K)) : Prop :=
  Function.Injective v ∧ LinearMap.range v = A ∧
  (∀ b, v (star b) = star (v b)) ∧ ‖v 1 - 1‖ ≤ δ ∧
  ∀ (n : ℕ) (X Y : Mat n B),
    ‖(X * Y).map v - matMul mul (X.map v) (Y.map v)‖ ≤ δ * ‖X‖ * ‖Y‖ ∧
    (1 - δ) * ‖X‖ ≤ ‖X.map v‖ ∧ ‖X.map v‖ ≤ (1 + δ) * ‖X‖

/-- **Theorem B, first sentence, extended version.** If Kitaev's Theorem 10.5 holds with
constants `C₃, ε₃`, then for `0 ≤ ε < ε₃` with `C₃ ε < 1`, the ℓ^∞-direct sum of any nonempty
family of finite-dimensional extended ε-C\* algebras is an extended ε-C\* algebra and is extended
`(C₃ ε)`-isomorphic to a C\* algebra. -/
def ClaimExt : Prop :=
  ∀ (C₃ ε₃ : ℝ), Kitaev10_5 C₃ ε₃ →
  ∀ (ε : ℝ), 0 ≤ ε → ε < ε₃ → C₃ * ε < 1 →
  ∀ (ι : Type) [DecidableEq ι] [Nonempty ι] (H : ι → Type) [∀ k, NormedAddCommGroup (H k)]
    [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]
    (Ak : ∀ k, Submodule ℂ (H k →L[ℂ] H k)) [∀ k, FiniteDimensional ℂ (Ak k)]
    (mulk : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k))
    (A : Submodule ℂ (lp H 2 →L[ℂ] lp H 2))
    (mul : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)),
    (∀ k, ExtEpsCStarSub ε (Ak k) (mulk k)) → IsBlockSumAlg A mul Ak mulk →
    ExtEpsCStarSub ε A mul ∧
    ∃ (B : Type) (_ : CStarAlgebra B) (_ : PartialOrder B) (_ : StarOrderedRing B)
      (v : B →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)), IsExtDeltaIsoOntoGen (C₃ * ε) A mul v

/-- **Theorem B, second sentence.** Assume what Theorem A assumes. There are constants
`η₀ > 0` and `C` such that for every nonempty family of nonzero Hilbert spaces `Hₖ` and UCP maps
`Φₖ` on `B(Hₖ)` with `‖Φₖ² - Φₖ‖_cb ≤ η < η₀` and `Φ̃ₖ` of finite rank, the block-diagonal map
`Φ = ⊕ₖ Φₖ(Pₖ · Pₖ)` on `B(⊕ₖ Hₖ)` is UCP with `‖Φ² - Φ‖_cb ≤ η`, and there are a C\* algebra
`B`, an extended `C η`-isomorphism `v : B → (Im Φ̃, ⋆)`, and UCP maps `Δ : B → B(⊕ₖ Hₖ)`,
`Υ : B(⊕ₖ Hₖ) → B` with `‖ΔΥ - Φ‖_cb ≤ C η` and `‖Υₙ(Δₙ(X) Δₙ(Y)) - XY‖ ≤ C η ‖X‖‖Y‖`. -/
def ClaimChannel : Prop :=
  CPMapFacts → StinespringThm → UnitaryDesign →
  ∀ (c₁ η₁ c₂ η₂ C₃ ε₃ : ℝ), 0 ≤ c₁ → 0 < η₁ → 0 ≤ c₂ → 0 < η₂ → 0 ≤ C₃ → 0 < ε₃ →
  Kitaev12_1 c₁ η₁ → Kitaev12_6 c₂ η₂ → Kitaev10_5 C₃ ε₃ →
  ∃ (η₀ C : ℝ), 0 < η₀ ∧
  ∀ (ι : Type) [DecidableEq ι] [Nonempty ι] (H : ι → Type) [∀ k, NormedAddCommGroup (H k)]
    [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]
    (Φk : ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k))
    (Φ : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)) (η : ℝ),
    (∀ k, IsUCP (Φk k).toLinearMap) → (∀ k, CBBound (Φk k * Φk k - Φk k).toLinearMap η) →
    0 ≤ η → η < η₀ →
    (∀ k, FiniteDimensional ℂ (LinearMap.range (tildePhi (Φk k)).toLinearMap)) →
    IsBlockSumMap Φ Φk →
    IsUCP Φ.toLinearMap ∧ CBBound (Φ * Φ - Φ).toLinearMap η ∧
    ∃ (B : Type) (_ : CStarAlgebra B) (_ : PartialOrder B) (_ : StarOrderedRing B)
      (v Δ : B →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)) (Υ : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] B),
      IsExtDeltaIsoOntoGen (C * η) (LinearMap.range (tildePhi Φ).toLinearMap) (choiEffros Φ) v ∧
      IsUCP Δ ∧ IsUCP Υ ∧
      CBBound (Δ ∘ₗ Υ - Φ.toLinearMap) (C * η) ∧
      ∀ (n : ℕ) (X Y : Mat n B),
        ‖(X.map Δ * Y.map Δ).map Υ - X * Y‖ ≤ C * η * ‖X‖ * ‖Y‖

/-- The rest of Theorem B: its first sentence for extended ε-C\* algebras, and its second
sentence (block-diagonal channels). -/
def Claim : Prop := ClaimExt ∧ ClaimChannel

end Cert.KitaevSectorSums
