import Certs.KitaevSectorSums.Proof
import Certs.KitaevChannels.Sanity
import Mathlib.LinearAlgebra.StdBasis
import Mathlib.RingTheory.Noetherian.Basic

/-!
# Non-vacuity checks for `Claim`

Both halves of `Claim` are about genuinely infinite-dimensional objects, and their hypotheses can
be met. Take countably many sectors, every `Hₖ = ℂ`, so that `⊕ₖ Hₖ = ℓ²(ℕ)`.

1. `ext_hyps_satisfiable`: for every `ε ≥ 0`, the sectors `Aₖ = B(ℂ)` with the operator product
   are (finite-dimensional) extended ε-C\* algebras, their block-diagonal sum is the algebra of
   diagonal operators on `ℓ²(ℕ)`, and that algebra is infinite-dimensional. So `ClaimExt` applies
   to an infinite-dimensional algebra.
2. `channel_hyps_satisfiable`: the sectors `Φₖ = id` satisfy every hypothesis of `ClaimChannel`
   for every `η ≥ 0`, their block sum is the pinching `x ↦ ⊕ₖ Pₖ x Pₖ` (the diagonal conditional
   expectation), and its `Φ̃` has infinite rank. So `ClaimChannel` is not a case of Theorem A,
   which needs `Φ̃` of finite rank.
-/

open scoped ComplexOrder ENNReal

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

section Pinch

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]

theorem norm_diagBlocks_le (x : lp H 2 →L[ℂ] lp H 2) : ‖diagBlocks x‖ ≤ ‖x‖ :=
  lp.norm_le_of_forall_le (norm_nonneg x) fun k => norm_blk_le k k x

theorem diagBlocks_bdOp (a : lp (fun k => H k →L[ℂ] H k) ∞) : diagBlocks (bdOp a) = a :=
  lp.ext (funext fun k => blk_bdOp_self a k)

/-- The pinching `x ↦ ⊕ₖ Pₖ x Pₖ`. -/
def pinch : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2) :=
  ((bdHom (H := H)).toAlgHom.toLinearMap ∘ₗ diagBlocksL).mkContinuous 1 fun x => by
    rw [one_mul]
    show ‖bdHom (diagBlocks x)‖ ≤ ‖x‖
    rw [NonUnitalStarAlgHom.norm_map (bdHom (H := H)) bdHom_injective]
    exact norm_diagBlocks_le x

theorem pinch_apply (x : lp H 2 →L[ℂ] lp H 2) : pinch x = bdOp (diagBlocks x) := rfl

/-- The pinching is the block sum of the identity maps. -/
theorem pinch_blockSum : IsBlockSumMap (pinch (H := H)) fun _ => 1 := fun _ =>
  ⟨fun k => blk_bdOp_self _ k, fun _ _ hkl => blk_bdOp_ne _ hkl⟩

theorem pinch_idem : pinch (H := H) * pinch = pinch := ContinuousLinearMap.ext fun x => by
  change bdOp (diagBlocks (bdOp (diagBlocks x))) = bdOp (diagBlocks x)
  rw [diagBlocks_bdOp]

theorem bdHom_mem_range_pinch (a : lp (fun k => H k →L[ℂ] H k) ∞) :
    bdHom a ∈ LinearMap.range (pinch (H := H)).toLinearMap :=
  LinearMap.mem_range.2 ⟨bdHom a, by
    change bdOp (diagBlocks (bdOp a)) = bdOp a
    rw [diagBlocks_bdOp]⟩

/-- The block-diagonal operators. -/
def bdSub : Submodule ℂ (lp H 2 →L[ℂ] lp H 2) where
  carrier := {x | IsBD x}
  add_mem' := isBD_add
  zero_mem' := isBD_zero
  smul_mem' c _ hx := isBD_smul c hx

/-- The block-diagonal operators, with the operator product, are the block-diagonal sum of the
full algebras `B(Hₖ)`. -/
theorem blockSumAlg_bd :
    IsBlockSumAlg (bdSub (H := H)) (LinearMap.mul ℂ _) (fun _ => ⊤) (fun _ => LinearMap.mul ℂ _) :=
  ⟨fun _ => ⟨fun hx => ⟨hx, fun _ => Submodule.mem_top⟩, fun h => h.1⟩,
    fun _ hx _ hy => ⟨fun k => blk_mul_of_BD hy k k, fun k l hkl => isBD_mul hx hy k l hkl⟩⟩

end Pinch

section Exact

variable {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]

theorem matMul_mul {n : ℕ} (X Y : Mat n (K →L[ℂ] K)) :
    matMul (LinearMap.mul ℂ (K →L[ℂ] K)) X Y = X * Y :=
  CStarMatrix.ext fun i j => by rw [CStarMatrix.mul_apply]; rfl

/-- `B(K)` with the operator product is an extended ε-C\* algebra for every `ε ≥ 0`. -/
theorem extEps_top {ε : ℝ} (hε : 0 ≤ ε) :
    ExtEpsCStarSub ε (⊤ : Submodule ℂ (K →L[ℂ] K)) (LinearMap.mul ℂ (K →L[ℂ] K)) := by
  refine ⟨Submodule.mem_top, fun _ _ => Submodule.mem_top, fun _ _ _ _ => Submodule.mem_top,
    fun x _ y _ => star_mul x y, fun x _ => ⟨mul_one x, one_mul x⟩,
    fun n X Y Z _ _ _ => ⟨?_, ?_, ?_⟩⟩
  · rw [matMul_mul]
    have h := norm_mul_le X Y
    have := mul_nonneg (mul_nonneg hε (norm_nonneg X)) (norm_nonneg Y)
    nlinarith
  · rw [matMul_mul, matMul_mul, matMul_mul, matMul_mul, mul_assoc, sub_self, norm_zero]
    exact mul_nonneg (mul_nonneg (mul_nonneg hε (norm_nonneg _)) (norm_nonneg _)) (norm_nonneg _)
  · have h : ‖star X * X‖ = ‖X‖ * ‖X‖ := CStarRing.norm_star_mul_self
    rw [matMul_mul, h]
    have := mul_nonneg hε (sq_nonneg ‖X‖)
    nlinarith

/-- The identity map of `B(K)` is UCP. -/
theorem id_ucp : IsUCP (1 : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)).toLinearMap := by
  refine ⟨rfl, fun n X hX => ?_⟩
  rw [show X.map (1 : (K →L[ℂ] K) →L[ℂ] (K →L[ℂ] K)).toLinearMap = X from
    CStarMatrix.ext fun _ _ => rfl]
  exact hX

end Exact

/-- `ℓ^∞(ℕ, B(ℂ))` is infinite-dimensional. -/
theorem linfty_not_finiteDimensional : ¬ FiniteDimensional ℂ (lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞) := by
  intro hfin
  let e : ℕ → lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞ := fun n => lp.single ∞ n 1
  let ev : lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞ →ₗ[ℂ] (ℕ → ℂ) :=
    { toFun := fun f n => f n 1, map_add' := fun _ _ => rfl, map_smul' := fun _ _ => rfl }
  have hli : LinearIndependent ℂ (ev ∘ e) := by
    have : ev ∘ e = fun n => Pi.single n (1 : ℂ) := by
      funext n m
      by_cases h : m = n
      · subst h
        change (lp.single ∞ m (1 : ℂ →L[ℂ] ℂ) : lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞) m 1 =
          (Pi.single m (1 : ℂ) : ℕ → ℂ) m
        rw [lp.single_apply_self, Pi.single_eq_same]
        rfl
      · change (lp.single ∞ n (1 : ℂ →L[ℂ] ℂ) : lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞) m 1 =
          (Pi.single n (1 : ℂ) : ℕ → ℂ) m
        rw [lp.single_apply_ne ∞ n _ h, Pi.single_eq_of_ne h]
        rfl
    rw [this]
    exact Pi.linearIndependent_single_one ℕ ℂ
  have : Finite ℕ := (LinearIndependent.of_comp ev hli).finite_of_isNoetherian
  exact (Infinite.not_finite this).elim

/-- An infinite-dimensional space of operators on `ℓ²(ℕ)` that contains every block-diagonal
`⊕ₖ aₖ`. -/
theorem not_finiteDimensional_of_bdHom_mem (S : Submodule ℂ
      (lp (fun _ : ℕ => ℂ) 2 →L[ℂ] lp (fun _ : ℕ => ℂ) 2))
    (hS : ∀ a, bdHom (H := fun _ : ℕ => ℂ) a ∈ S) : ¬ FiniteDimensional ℂ S := by
  intro hfin
  let f : lp (fun _ : ℕ => ℂ →L[ℂ] ℂ) ∞ →ₗ[ℂ] S :=
    LinearMap.codRestrict S (bdHom (H := fun _ : ℕ => ℂ)).toAlgHom.toLinearMap hS
  have hf : Function.Injective f := fun a b h => bdHom_injective (congrArg Subtype.val h)
  exact linfty_not_finiteDimensional (FiniteDimensional.of_injective (K := ℂ) (V₂ := S) f hf)

/-- **(1) `ClaimExt` applies to an infinite-dimensional algebra.** -/
theorem ext_hyps_satisfiable (ε : ℝ) (hε : 0 ≤ ε) :
    (∀ _ : ℕ, FiniteDimensional ℂ (⊤ : Submodule ℂ (ℂ →L[ℂ] ℂ))) ∧
    (∀ _ : ℕ, ExtEpsCStarSub ε (⊤ : Submodule ℂ (ℂ →L[ℂ] ℂ)) (LinearMap.mul ℂ (ℂ →L[ℂ] ℂ))) ∧
    IsBlockSumAlg (bdSub (H := fun _ : ℕ => ℂ)) (LinearMap.mul ℂ _) (fun _ => ⊤)
      (fun _ => LinearMap.mul ℂ _) ∧
    ¬ FiniteDimensional ℂ (bdSub (H := fun _ : ℕ => ℂ)) :=
  ⟨fun _ => inferInstance, fun _ => extEps_top hε, blockSumAlg_bd,
    not_finiteDimensional_of_bdHom_mem _ fun a => isBD_bdOp a⟩

set_option synthInstance.maxHeartbeats 200000 in
/-- **(2) `ClaimChannel` applies to a channel whose `Φ̃` has infinite rank.** -/
theorem channel_hyps_satisfiable :
    ∃ (Φk : ℕ → (ℂ →L[ℂ] ℂ) →L[ℂ] (ℂ →L[ℂ] ℂ))
      (Φ : (lp (fun _ : ℕ => ℂ) 2 →L[ℂ] lp (fun _ : ℕ => ℂ) 2) →L[ℂ]
        (lp (fun _ : ℕ => ℂ) 2 →L[ℂ] lp (fun _ : ℕ => ℂ) 2)),
      (∀ k, IsUCP (Φk k).toLinearMap) ∧
      (∀ η : ℝ, 0 ≤ η → ∀ k, CBBound (Φk k * Φk k - Φk k).toLinearMap η) ∧
      (∀ k, FiniteDimensional ℂ (LinearMap.range (tildePhi (Φk k)).toLinearMap)) ∧
      IsBlockSumMap (H := fun _ : ℕ => ℂ) Φ Φk ∧
      ¬ FiniteDimensional ℂ (LinearMap.range (tildePhi Φ).toLinearMap) := by
  refine ⟨fun _ => 1, pinch, fun _ => id_ucp, fun η hη _ => ?_, fun _ => inferInstance,
    pinch_blockSum, ?_⟩
  · have h0 : ((1 : (ℂ →L[ℂ] ℂ) →L[ℂ] (ℂ →L[ℂ] ℂ)) * 1 - 1) = 0 :=
      ContinuousLinearMap.ext fun x => sub_self x
    show CBBound ((1 : (ℂ →L[ℂ] ℂ) →L[ℂ] (ℂ →L[ℂ] ℂ)) * 1 - 1).toLinearMap η
    rw [h0, ContinuousLinearMap.toLinearMap_zero]
    exact CBBound.zero.mono hη
  · rw [tildePhi_of_idem pinch_idem]
    exact not_finiteDimensional_of_bdHom_mem _ bdHom_mem_range_pinch

end Cert.KitaevSectorSums
