import Certs.KitaevSectorSums.Channel

/-!
# Assembling Theorem B from sector data

Given, in every sector `k`, the conclusions of Theorem A for `Φₖ` (an extended δ-isomorphism
`vₖ : Eₖ → Im Φ̃ₖ` and UCP maps `Δₖ, Υₖ` with the two bounds), the block-diagonal maps
`v = ⊕ vₖ`, `Δ = ⊕ Δₖ` and `Υ = (Υₖ(Pₖ · Pₖ))ₖ` give the conclusions of Theorem B for
`Φ = ⊕ₖ Φₖ(Pₖ · Pₖ)`, with `ℓ^∞(Eₖ)` in place of the block algebra and the same constant δ.
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]
  {E : ι → Type} [∀ k, CStarAlgebra (E k)] [∀ k, PartialOrder (E k)]
  [∀ k, StarOrderedRing (E k)] [∀ k, Nontrivial (E k)]

section Maps

variable {Δ : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)} {Υ : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] E k}

theorem ucp_bound_Δ (hF : CPMapFacts) (hΔ : ∀ k, IsUCP (Δ k)) (k : ι) (b : E k) :
    ‖Δ k b‖ ≤ 1 * ‖b‖ :=
  (cb_of_ucp hF (hΔ k)).apply_le b

theorem ucp_bound_Υ (hF : CPMapFacts) (hΥ : ∀ k, IsUCP (Υ k)) (k : ι) (x : H k →L[ℂ] H k) :
    ‖Υ k x‖ ≤ 1 * ‖x‖ :=
  (cb_of_ucp hF (hΥ k)).apply_le x

/-- `Δ = ⊕ₖ Δₖ : ℓ^∞(E) → B(⊕ₖ Hₖ)`. -/
def DeltaSum (hF : CPMapFacts) (hΔ : ∀ k, IsUCP (Δ k)) : lp E ∞ →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) :=
  bdMap Δ zero_le_one (ucp_bound_Δ hF hΔ)

/-- `Υ = (Υₖ(Pₖ · Pₖ))ₖ : B(⊕ₖ Hₖ) → ℓ^∞(E)`. -/
def UpsSum (hF : CPMapFacts) (hΥ : ∀ k, IsUCP (Υ k)) : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] lp E ∞ :=
  sectorMap Υ zero_le_one (ucp_bound_Υ hF hΥ)

theorem deltaSum_ucp (hF : CPMapFacts) (hΔ : ∀ k, IsUCP (Δ k)) : IsUCP (DeltaSum hF hΔ) := by
  refine ⟨op_ext fun k l => ?_, fun n X hX => ?_⟩
  · by_cases hkl : k = l
    · subst hkl
      rw [DeltaSum, blk_bdMap_self, blk_one_self, lp.infty_coeFn_one, Pi.one_apply]
      exact (hΔ k).1
    · rw [DeltaSum, isBD_bdMap _ _ _ _ k l hkl, isBD_one k l hkl]
  · refine nonneg_of_BD (isBDMat_map_bdMap _ _ _ X) fun k => ?_
    rw [DeltaSum, map_bdMap_blk]
    exact (hΔ k).2 n _ (sectors_of_nonneg hX k)

theorem upsSum_ucp (hF : CPMapFacts) (hS : StinespringThm) (hΥ : ∀ k, IsUCP (Υ k)) :
    IsUCP (UpsSum hF hΥ) := by
  refine ⟨lp.ext (funext fun k => ?_), fun n X hX => ?_⟩
  · change Υ k (blk k k 1) = ((1 : lp E ∞) : ∀ k, E k) k
    rw [blk_one_self, lp.infty_coeFn_one, Pi.one_apply]
    exact (hΥ k).1
  · refine nonneg_of_sectors _ fun k => ?_
    rw [UpsSum, map_sectorMap_eval]
    exact (hΥ k).2 n _ (blk_cp hS k n X hX)

end Maps

/-- **Theorem B from sector data.** -/
theorem channel_sum (hF : CPMapFacts) (hS : StinespringThm)
    {Φk : ∀ k, (H k →L[ℂ] H k) →L[ℂ] (H k →L[ℂ] H k)}
    {Φ : (lp H 2 →L[ℂ] lp H 2) →L[ℂ] (lp H 2 →L[ℂ] lp H 2)} (hΦ : IsBlockSumMap Φ Φk)
    {η : ℝ} (hucp : ∀ k, IsUCP (Φk k).toLinearMap)
    (hcb : ∀ k, CBBound (Φk k * Φk k - Φk k).toLinearMap η) (hη : 0 ≤ η) (h4 : 4 * η < 1)
    {ε : ℝ}
    (hA : ∀ k, ExtEpsCStarSub ε (LinearMap.range (tildePhi (Φk k)).toLinearMap) (choiEffros (Φk k)))
    {v Δ : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)} {Υ : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] E k} {δ : ℝ}
    (hδ0 : 0 ≤ δ) (hδ1 : δ < 1)
    (hv : ∀ k, IsExtDeltaIsoOntoGen δ (LinearMap.range (tildePhi (Φk k)).toLinearMap)
      (choiEffros (Φk k)) (v k))
    (hΔ : ∀ k, IsUCP (Δ k)) (hΥ : ∀ k, IsUCP (Υ k))
    (hΔΥ : ∀ k, CBBound (Δ k ∘ₗ Υ k - (Φk k).toLinearMap) δ)
    (hmul : ∀ k (n : ℕ) (X Y : Mat n (E k)),
      ‖(X.map (Δ k) * Y.map (Δ k)).map (Υ k) - X * Y‖ ≤ δ * ‖X‖ * ‖Y‖) :
    IsUCP Φ.toLinearMap ∧ CBBound (Φ * Φ - Φ).toLinearMap η ∧
    ∃ (B : Type) (_ : CStarAlgebra B) (_ : PartialOrder B) (_ : StarOrderedRing B)
      (v' Δ' : B →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)) (Υ' : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] B),
      IsExtDeltaIsoOntoGen δ (LinearMap.range (tildePhi Φ).toLinearMap) (choiEffros Φ) v' ∧
      IsUCP Δ' ∧ IsUCP Υ' ∧ CBBound (Δ' ∘ₗ Υ' - Φ.toLinearMap) δ ∧
      ∀ (n : ℕ) (X Y : Mat n B),
        ‖(X.map Δ' * Y.map Δ').map Υ' - X * Y‖ ≤ δ * ‖X‖ * ‖Y‖ := by
  have hdcΦ := dc_of_blockSum hΦ
  have hbdΦ := bdv_of_blockSum hΦ
  -- `Φ` is UCP and η-idempotent
  have hΦucp : IsUCP Φ.toLinearMap := by
    refine ⟨op_ext fun k l => ?_, cp_of_sectors (Tk := fun k => (Φk k).toLinearMap) hS hbdΦ hdcΦ
      fun k => (hucp k).2⟩
    by_cases hkl : k = l
    · subst hkl
      change blk k k (Φ 1) = blk k k 1
      rw [hdcΦ, blk_one_self]
      exact (hucp k).1
    · exact (hbdΦ 1 k l hkl).trans (isBD_one k l hkl).symm
  have hΦcb : CBBound (Φ * Φ - Φ).toLinearMap η :=
    cb_of_sectors (Tk := fun k => (Φk k * Φk k - Φk k).toLinearMap) hF hS
      (bdv_sub (bdv_mul_left hbdΦ) hbdΦ) (dc_sub (dc_mul hdcΦ hdcΦ) hdcΦ) hη hcb
  refine ⟨hΦucp, hΦcb, ?_⟩
  -- `(Im Φ̃, ⋆)` is the block-diagonal sum of the sector algebras
  have hsum := blockSumAlg_tilde
    (dc_tilde hΦ (summable_series hΦcb hη h4) fun k => summable_series (hcb k) hη h4)
    (bdv_tilde hΦ (summable_series hΦcb hη h4)) fun k _ hy => tilde_fix (hA k) hy
  refine ⟨lp E ∞, inferInstance, inferInstance, inferInstance, isoSum hv hδ0, DeltaSum hF hΔ,
    UpsSum hF hΥ, iso_sum hv hδ0 hsum hδ1,
    deltaSum_ucp hF hΔ, upsSum_ucp hF hS hΥ, ?_, fun n X Y => ?_⟩
  · -- `‖ΔΥ - Φ‖_cb ≤ δ`, sector by sector
    refine cb_of_sectors (Tk := fun k => Δ k ∘ₗ Υ k - (Φk k).toLinearMap) hF hS (fun x => ?_)
      (fun k x => ?_) hδ0 hΔΥ
    · exact isBD_sub (isBD_bdMap _ _ _ _) (hbdΦ x)
    · change blk k k (DeltaSum hF hΔ (UpsSum hF hΥ x) - Φ x) = Δ k (Υ k (blk k k x)) - Φk k (blk k k x)
      rw [← blkL_apply, map_sub, blkL_apply, blkL_apply, DeltaSum, blk_bdMap_self, hdcΦ]
      rfl
  · -- the product bound, sector by sector
    refine norm_le_of_sectors _ (mul_nonneg (mul_nonneg hδ0 (norm_nonneg X)) (norm_nonneg Y))
      fun k => ?_
    have hm : ∀ Z W : Mat n (lp E ∞), (Z * W).map (evalHom (A := E) k) =
        Z.map (evalHom (A := E) k) * W.map (evalHom (A := E) k) :=
      fun Z W => map_mul (matHom n (evalHom (A := E) k)) Z W
    have hs : ∀ Z W : Mat n (lp E ∞), (Z - W).map (evalHom (A := E) k) =
        Z.map (evalHom (A := E) k) - W.map (evalHom (A := E) k) :=
      fun Z W => map_sub (matHom n (evalHom (A := E) k)) Z W
    rw [hs, hm, UpsSum, map_sectorMap_eval, DeltaSum,
      map_blk_mul (isBDMat_map_bdMap _ _ _ Y), map_bdMap_blk, map_bdMap_blk]
    exact (hmul k n _ _).trans (real_le2 hδ0 (norm_nonneg _) (norm_nonneg _)
      (norm_map_evalHom_le X k) (norm_map_evalHom_le Y k))

end Cert.KitaevSectorSums
