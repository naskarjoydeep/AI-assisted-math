import Certs.KitaevSectorSums.Statement
import Certs.KitaevChannels.Final
import Mathlib.Analysis.CStarAlgebra.lpSpace
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Isometric

/-!
# `ℓ^∞` of C\*-algebras: unit, order, and matrices computed sector by sector

For a family of C\*-algebras `A k`, Mathlib makes `lp A ∞` a non-unital C\*-algebra. We add the
unital structure (all components nontrivial) and the C\*-order (`CStarAlgebra.spectralOrder`), and
prove that norms and positivity of matrices over `lp A ∞` are computed componentwise.
-/

open scoped ComplexOrder ENNReal NNReal

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

section Instances

variable {ι : Type} {A : ι → Type}

instance lpPartialOrder [∀ k, NonUnitalCStarAlgebra (A k)] : PartialOrder (lp A ∞) :=
  CStarAlgebra.spectralOrder _

instance lpStarOrderedRing [∀ k, NonUnitalCStarAlgebra (A k)] : StarOrderedRing (lp A ∞) :=
  CStarAlgebra.spectralOrderedRing _

instance lpCStarAlgebra [∀ k, CStarAlgebra (A k)] [∀ k, Nontrivial (A k)] :
    CStarAlgebra (lp A ∞) where

end Instances

section Positivity

variable {ι : Type} {C : ι → Type} [∀ k, NonUnitalCStarAlgebra (C k)] [∀ k, PartialOrder (C k)]
  [∀ k, StarOrderedRing (C k)]

/-- Evaluation at a coordinate, as a non-unital star algebra homomorphism. -/
def evalN (k : ι) : lp C ∞ →⋆ₙₐ[ℂ] C k where
  toFun f := f k
  map_smul' _ _ := rfl
  map_zero' := rfl
  map_add' _ _ := rfl
  map_mul' f g := by rw [lp.infty_coeFn_mul]; rfl
  map_star' f := lp.star_apply f k

theorem evalN_apply (k : ι) (f : lp C ∞) : evalN k f = f k := rfl

/-- **Positivity in `ℓ^∞` is componentwise.** -/
theorem lp_nonneg_iff (y : lp C ∞) : 0 ≤ y ↔ ∀ k, 0 ≤ y k := by
  constructor
  · intro hy k
    have := OrderHomClass.mono (evalN (C := C) k) hy
    simpa [evalN_apply] using this
  · intro hy
    have hb : BddAbove (Set.range fun k => ‖CFC.sqrt (y k)‖) := by
      refine ⟨Real.sqrt ‖y‖, ?_⟩
      rintro _ ⟨k, rfl⟩
      dsimp only
      rw [CFC.norm_sqrt (y k) (hy k)]
      exact Real.sqrt_le_sqrt (lp.norm_apply_le_norm ENNReal.top_ne_zero y k)
    let z : lp C ∞ := ⟨fun k => CFC.sqrt (y k), memℓp_infty hb⟩
    have hz : star z * z = y := by
      refine lp.ext (funext fun k => ?_)
      rw [lp.infty_coeFn_mul, Pi.mul_apply, lp.star_apply]
      change star (CFC.sqrt (y k)) * CFC.sqrt (y k) = y k
      rw [(CFC.sqrt_nonneg (y k)).isSelfAdjoint.star_eq, CFC.sqrt_mul_sqrt_self (y k) (hy k)]
    rw [← hz]
    exact star_mul_self_nonneg z

end Positivity

section Matrices

variable {ι : Type} {A : ι → Type} [∀ k, CStarAlgebra (A k)] [∀ k, PartialOrder (A k)]
  [∀ k, StarOrderedRing (A k)] [∀ k, Nontrivial (A k)]

/-- Evaluation at a coordinate, as a unital star algebra homomorphism. -/
def evalHom (k : ι) : lp A ∞ →⋆ₐ[ℂ] A k where
  toFun f := f k
  map_one' := by rw [lp.infty_coeFn_one]; rfl
  map_mul' f g := by rw [lp.infty_coeFn_mul]; rfl
  map_zero' := rfl
  map_add' _ _ := rfl
  commutes' c := by
    rw [Algebra.algebraMap_eq_smul_one, Algebra.algebraMap_eq_smul_one]
    change ((c • (1 : lp A ∞) : lp A ∞) : ∀ k, A k) k = c • (1 : A k)
    rw [lp.coeFn_smul, lp.infty_coeFn_one]; rfl
  map_star' f := lp.star_apply f k

theorem evalHom_apply (k : ι) (f : lp A ∞) : evalHom k f = f k := rfl

theorem norm_entry_le {n : ℕ} (X : Mat n (lp A ∞)) (k : ι) (i j : Fin n) :
    ‖X i j k‖ ≤ ‖X‖ :=
  (lp.norm_apply_le_norm ENNReal.top_ne_zero (X i j) k).trans CStarMatrix.norm_entry_le_norm

theorem norm_map_evalHom_le {n : ℕ} (X : Mat n (lp A ∞)) (k : ι) :
    ‖X.map (evalHom (A := A) k)‖ ≤ ‖X‖ :=
  NonUnitalStarAlgHom.norm_apply_le (matHom n (evalHom (A := A) k)) X

/-- `Mₙ(ℓ^∞(A)) → ℓ^∞(Mₙ(A))`, entrywise evaluation, as a non-unital star homomorphism. -/
def matSplit (n : ℕ) : Mat n (lp A ∞) →⋆ₙₐ[ℂ] lp (fun k => Mat n (A k)) ∞ where
  toFun X := ⟨fun k => X.map (evalHom (A := A) k), memℓp_infty ⟨‖X‖, by
    rintro _ ⟨k, rfl⟩; exact norm_map_evalHom_le X k⟩⟩
  map_smul' c X := by
    refine lp.ext (funext fun k => ?_)
    exact (map_smul (matHom n (evalHom (A := A) k)) c X)
  map_zero' := by
    refine lp.ext (funext fun k => ?_)
    exact map_zero (matHom n (evalHom (A := A) k))
  map_add' X Y := by
    refine lp.ext (funext fun k => ?_)
    exact map_add (matHom n (evalHom (A := A) k)) X Y
  map_mul' X Y := by
    refine lp.ext (funext fun k => ?_)
    rw [lp.infty_coeFn_mul]
    exact map_mul (matHom n (evalHom (A := A) k)) X Y
  map_star' X := by
    refine lp.ext (funext fun k => ?_)
    rw [lp.coeFn_star]
    exact map_star (matHom n (evalHom (A := A) k)) X

theorem matSplit_apply (n : ℕ) (X : Mat n (lp A ∞)) (k : ι) :
    matSplit n X k = X.map (evalHom (A := A) k) := rfl

theorem matSplit_injective (n : ℕ) : Function.Injective (matSplit (A := A) n) := by
  intro X Y h
  refine CStarMatrix.ext fun i j => lp.ext (funext fun k => ?_)
  have := congrArg (fun F : lp (fun k => Mat n (A k)) ∞ => F k i j) h
  simpa [matSplit_apply, evalHom_apply] using this

theorem norm_matSplit (n : ℕ) (X : Mat n (lp A ∞)) : ‖matSplit n X‖ = ‖X‖ :=
  NonUnitalStarAlgHom.norm_map (matSplit n) (matSplit_injective n) X

/-- **Matrix norms over `ℓ^∞` are suprema over the sectors.** -/
theorem norm_le_of_sectors {n : ℕ} (X : Mat n (lp A ∞)) {c : ℝ} (hc : 0 ≤ c)
    (h : ∀ k, ‖X.map (evalHom (A := A) k)‖ ≤ c) : ‖X‖ ≤ c := by
  rw [← norm_matSplit]
  exact lp.norm_le_of_forall_le hc fun k => h k

/-- **Matrix positivity over `ℓ^∞` is sectorwise.** -/
theorem nonneg_of_sectors {n : ℕ} (X : Mat n (lp A ∞))
    (h : ∀ k, 0 ≤ X.map (evalHom (A := A) k)) : 0 ≤ X := by
  have h' : matSplit n 0 ≤ matSplit n X := by
    rw [map_zero, ← sub_nonneg, sub_zero, lp_nonneg_iff]
    exact fun k => h k
  exact (NonUnitalStarAlgHom.map_le_map_iff (matSplit (A := A) n) (matSplit_injective n)).1 h'

theorem sectors_of_nonneg {n : ℕ} {X : Mat n (lp A ∞)} (hX : 0 ≤ X) (k : ι) :
    0 ≤ X.map (evalHom (A := A) k) := by
  have := OrderHomClass.mono (matHom n (evalHom (A := A) k)) hX
  rw [map_zero] at this
  exact this

end Matrices

end Cert.KitaevSectorSums
