import Certs.KitaevSectorSums.Assemble

/-!
# The extended sector sum (Theorem B, first sentence, extended version)

The block-diagonal sum of extended ε-C\* algebras is an extended ε-C\* algebra, and coordinatewise
extended δ-isomorphisms `vₖ : Bₖ → Aₖ` with a common `δ < 1` assemble into an extended
δ-isomorphism `ℓ^∞(Bₖ) → A`.
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]

theorem real_le3 {e a b c a' b' c' : ℝ} (he : 0 ≤ e) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c)
    (h1 : a ≤ a') (h2 : b ≤ b') (h3 : c ≤ c') : e * a * b * c ≤ e * a' * b' * c' := by
  have := mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left h1 he) h2 hb
    (mul_nonneg he (ha.trans h1))) h3 hc
    (mul_nonneg (mul_nonneg he (ha.trans h1)) (hb.trans h2))
  linarith

theorem real_le2 {e a b a' b' : ℝ} (he : 0 ≤ e) (ha : 0 ≤ a) (hb : 0 ≤ b)
    (h1 : a ≤ a') (h2 : b ≤ b') : e * a * b ≤ e * a' * b' :=
  mul_le_mul (mul_le_mul_of_nonneg_left h1 he) h2 hb (mul_nonneg he (ha.trans h1))

section Algebra

variable {A : Submodule ℂ (lp H 2 →L[ℂ] lp H 2)}
  {mul : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)}
  {Ak : ∀ k, Submodule ℂ (H k →L[ℂ] H k)}
  {mulk : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k)}
  (hsum : IsBlockSumAlg A mul Ak mulk)
include hsum

theorem isBD_of_mem {x : lp H 2 →L[ℂ] lp H 2} (hx : x ∈ A) : IsBD x := ((hsum.1 x).1 hx).1

theorem blk_mem_of_mem {x : lp H 2 →L[ℂ] lp H 2} (hx : x ∈ A) (k : ι) : blk k k x ∈ Ak k :=
  ((hsum.1 x).1 hx).2 k

theorem mem_of_blocks {x : lp H 2 →L[ℂ] lp H 2} (hx : IsBD x) (hk : ∀ k, blk k k x ∈ Ak k) :
    x ∈ A := (hsum.1 x).2 ⟨hx, hk⟩

theorem isBD_mul_of_mem {x y : lp H 2 →L[ℂ] lp H 2} (hx : x ∈ A) (hy : y ∈ A) : IsBD (mul x y) :=
  (hsum.2 x hx y hy).2

theorem blk_mul_of_mem {x y : lp H 2 →L[ℂ] lp H 2} (hx : x ∈ A) (hy : y ∈ A) (k : ι) :
    blk k k (mul x y) = mulk k (blk k k x) (blk k k y) := (hsum.2 x hx y hy).1 k

variable {n : ℕ}

theorem isBDMat_of_mem {X : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : ∀ i j, X i j ∈ A) : IsBDMat X :=
  fun i j => isBD_of_mem hsum (hX i j)

theorem matMul_mem {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : ∀ i j, X i j ∈ A)
    (hY : ∀ i j, Y i j ∈ A) (hmul : ∀ x ∈ A, ∀ y ∈ A, mul x y ∈ A) (i j : Fin n) :
    matMul mul X Y i j ∈ A := by
  change ∑ l, mul (X i l) (Y l j) ∈ A
  exact Submodule.sum_mem _ fun l _ => hmul _ (hX i l) _ (hY l j)

theorem isBDMat_matMul {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : ∀ i j, X i j ∈ A)
    (hY : ∀ i j, Y i j ∈ A) : IsBDMat (matMul mul X Y) := by
  intro i j k l hkl
  change blkL k l (∑ m, mul (X i m) (Y m j)) = 0
  rw [map_sum]
  exact Finset.sum_eq_zero fun m _ => isBD_mul_of_mem hsum (hX i m) (hY m j) k l hkl

theorem map_blk_matMul {X Y : Mat n (lp H 2 →L[ℂ] lp H 2)} (hX : ∀ i j, X i j ∈ A)
    (hY : ∀ i j, Y i j ∈ A) (k : ι) :
    (matMul mul X Y).map (blkL k k) = matMul (mulk k) (X.map (blkL k k)) (Y.map (blkL k k)) := by
  refine CStarMatrix.ext fun i j => ?_
  change blkL k k (∑ m, mul (X i m) (Y m j)) = ∑ m, mulk k (blk k k (X i m)) (blk k k (Y m j))
  rw [map_sum]
  exact Finset.sum_congr rfl fun m _ => blk_mul_of_mem hsum (hX i m) (hY m j) k

/-- **The sum of extended ε-C\* algebras is an extended ε-C\* algebra.** -/
theorem extEps_sum {ε : ℝ} (hε : 0 ≤ ε) (hAk : ∀ k, ExtEpsCStarSub ε (Ak k) (mulk k)) :
    ExtEpsCStarSub ε A mul := by
  have hone : (1 : lp H 2 →L[ℂ] lp H 2) ∈ A :=
    mem_of_blocks hsum isBD_one fun k => by rw [blk_one_self]; exact (hAk k).1
  have hstar : ∀ x ∈ A, star x ∈ A := fun x hx =>
    mem_of_blocks hsum (isBD_star (isBD_of_mem hsum hx)) fun k => by
      rw [blk_star, ← ContinuousLinearMap.star_eq_adjoint]
      exact (hAk k).2.1 _ (blk_mem_of_mem hsum hx k)
  have hmul : ∀ x ∈ A, ∀ y ∈ A, mul x y ∈ A := fun x hx y hy =>
    mem_of_blocks hsum (isBD_mul_of_mem hsum hx hy) fun k => by
      rw [blk_mul_of_mem hsum hx hy]
      exact (hAk k).2.2.1 _ (blk_mem_of_mem hsum hx k) _ (blk_mem_of_mem hsum hy k)
  refine ⟨hone, hstar, hmul, fun x hx y hy => ?_, fun x hx => ⟨?_, ?_⟩, fun n X Y Z hX hY hZ => ?_⟩
  · refine op_ext fun k l => ?_
    by_cases hkl : k = l
    · subst hkl
      rw [blk_star, blk_mul_of_mem hsum hx hy, blk_mul_of_mem hsum (hstar y hy) (hstar x hx),
        ← ContinuousLinearMap.star_eq_adjoint, (hAk k).2.2.2.1 _ (blk_mem_of_mem hsum hx k) _
          (blk_mem_of_mem hsum hy k), blk_star, blk_star, ContinuousLinearMap.star_eq_adjoint,
        ContinuousLinearMap.star_eq_adjoint]
    · rw [isBD_star (isBD_mul_of_mem hsum hx hy) k l hkl,
        isBD_mul_of_mem hsum (hstar y hy) (hstar x hx) k l hkl]
  · refine op_ext fun k l => ?_
    by_cases hkl : k = l
    · subst hkl
      rw [blk_mul_of_mem hsum hx hone, blk_one_self, ((hAk k).2.2.2.2.1 _ (blk_mem_of_mem hsum hx k)).1]
    · rw [isBD_mul_of_mem hsum hx hone k l hkl, isBD_of_mem hsum hx k l hkl]
  · refine op_ext fun k l => ?_
    by_cases hkl : k = l
    · subst hkl
      rw [blk_mul_of_mem hsum hone hx, blk_one_self, ((hAk k).2.2.2.2.1 _ (blk_mem_of_mem hsum hx k)).2]
    · rw [isBD_mul_of_mem hsum hone hx k l hkl, isBD_of_mem hsum hx k l hkl]
  · have hXk : ∀ k, ∀ i j, X.map (blkL k k) i j ∈ Ak k := fun k i j => blk_mem_of_mem hsum (hX i j) k
    have hYk : ∀ k, ∀ i j, Y.map (blkL k k) i j ∈ Ak k := fun k i j => blk_mem_of_mem hsum (hY i j) k
    have hZk : ∀ k, ∀ i j, Z.map (blkL k k) i j ∈ Ak k := fun k i j => blk_mem_of_mem hsum (hZ i j) k
    have bX := isBDMat_of_mem hsum hX
    have bY := isBDMat_of_mem hsum hY
    have bZ := isBDMat_of_mem hsum hZ
    have hXYmem := matMul_mem hsum hX hY hmul
    have hYZmem := matMul_mem hsum hY hZ hmul
    have h1ε : 0 ≤ 1 + ε := by linarith
    refine ⟨?_, ?_, ?_⟩
    · refine norm_le_of_BD (isBDMat_matMul hsum hX hY)
        (mul_nonneg (mul_nonneg h1ε (norm_nonneg X)) (norm_nonneg Y)) fun k => ?_
      rw [map_blk_matMul hsum hX hY]
      exact ((hAk k).2.2.2.2.2 n _ _ _ (hXk k) (hYk k) (hYk k)).1.trans
        (real_le2 h1ε (norm_nonneg _) (norm_nonneg _) (norm_sector_le bX k) (norm_sector_le bY k))
    · refine norm_le_of_BD (isBDMat_sub (isBDMat_matMul hsum hXYmem hZ)
        (isBDMat_matMul hsum hX hYZmem))
        (mul_nonneg (mul_nonneg (mul_nonneg hε (norm_nonneg X)) (norm_nonneg Y)) (norm_nonneg Z))
        fun k => ?_
      rw [amp_sub, map_blk_matMul hsum hXYmem hZ, map_blk_matMul hsum hX hY,
        map_blk_matMul hsum hX hYZmem, map_blk_matMul hsum hY hZ]
      exact ((hAk k).2.2.2.2.2 n _ _ _ (hXk k) (hYk k) (hZk k)).2.1.trans
        (real_le3 hε (norm_nonneg _) (norm_nonneg _) (norm_nonneg _) (norm_sector_le bX k)
          (norm_sector_le bY k) (norm_sector_le bZ k))
    · have hsX : ∀ i j, (star X) i j ∈ A := fun i j => by
        rw [CStarMatrix.star_apply]; exact hstar _ (hX j i)
      set r := ‖matMul mul (star X) X‖ with hr
      have hsec : ∀ k, (1 - ε) * ‖X.map (blkL k k)‖ ^ 2 ≤ r := fun k => by
        have h := ((hAk k).2.2.2.2.2 n (X.map (blkL k k)) (X.map (blkL k k)) (X.map (blkL k k))
          (hXk k) (hXk k) (hXk k)).2.2
        have e := map_blk_matMul hsum hsX hX k
        rw [map_blk_star] at e
        rw [← e] at h
        exact h.trans (norm_sector_le (isBDMat_matMul hsum hsX hX) k)
      by_cases hε1 : 1 - ε ≤ 0
      · have := mul_nonpos_of_nonpos_of_nonneg hε1 (sq_nonneg ‖X‖)
        linarith [norm_nonneg (matMul mul (star X) X)]
      · push Not at hε1
        have hXle : ‖X‖ ≤ Real.sqrt (r / (1 - ε)) :=
          norm_le_of_BD bX (Real.sqrt_nonneg _) fun k => by
            rw [Real.le_sqrt (norm_nonneg _) (div_nonneg (norm_nonneg _) hε1.le), le_div_iff₀ hε1]
            linarith [hsec k]
        have h2 : ‖X‖ ^ 2 ≤ r / (1 - ε) := by
          have := pow_le_pow_left₀ (norm_nonneg X) hXle 2
          rwa [Real.sq_sqrt (div_nonneg (norm_nonneg _) hε1.le)] at this
        rw [le_div_iff₀ hε1] at h2
        linarith

end Algebra

section Iso

variable {A : Submodule ℂ (lp H 2 →L[ℂ] lp H 2)}
  {mul : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2)}
  {Ak : ∀ k, Submodule ℂ (H k →L[ℂ] H k)}
  {mulk : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k) →ₗ[ℂ] (H k →L[ℂ] H k)}
  {E : ι → Type} [∀ k, CStarAlgebra (E k)] [∀ k, PartialOrder (E k)]
  [∀ k, StarOrderedRing (E k)] [∀ k, Nontrivial (E k)]
  {v : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)} {δ : ℝ}

/-- Level-one bounds of an extended δ-isomorphism. -/
theorem isoGen_upper {B : Type} [CStarAlgebra B] [PartialOrder B] [StarOrderedRing B]
    {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
    {S : Submodule ℂ (K →L[ℂ] K)} {mul' : (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K)}
    {w : B →ₗ[ℂ] (K →L[ℂ] K)} (hw : IsExtDeltaIsoOntoGen δ S mul' w) (b : B) :
    ‖w b‖ ≤ (1 + δ) * ‖b‖ := by
  have := (hw.2.2.2.2 1 (diagM 1 b) 0).2.2
  rwa [amp_diagM, norm_diagM_one, norm_diagM_one] at this

theorem isoGen_lower {B : Type} [CStarAlgebra B] [PartialOrder B] [StarOrderedRing B]
    {K : Type} [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
    {S : Submodule ℂ (K →L[ℂ] K)} {mul' : (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K) →ₗ[ℂ] (K →L[ℂ] K)}
    {w : B →ₗ[ℂ] (K →L[ℂ] K)} (hw : IsExtDeltaIsoOntoGen δ S mul' w) (b : B) :
    (1 - δ) * ‖b‖ ≤ ‖w b‖ := by
  have := (hw.2.2.2.2 1 (diagM 1 b) 0).2.1
  rwa [amp_diagM, norm_diagM_one, norm_diagM_one] at this

variable (hv : ∀ k, IsExtDeltaIsoOntoGen δ (Ak k) (mulk k) (v k)) (hδ0 : 0 ≤ δ)

/-- The assembled map `b ↦ ⊕ₖ vₖ(bₖ)`. -/
def isoSum : lp E ∞ →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) :=
  bdMap v (by linarith : (0 : ℝ) ≤ 1 + δ) fun k b => isoGen_upper (hv k) b

theorem isoSum_blk (b : lp E ∞) (k : ι) : blk k k (isoSum hv hδ0 b) = v k (b k) :=
  blk_bdMap_self _ _ _ b k

theorem isoSum_isBD (b : lp E ∞) : IsBD (isoSum hv hδ0 b) := isBD_bdMap _ _ _ b

theorem isoSum_isBDMat {n : ℕ} (X : Mat n (lp E ∞)) : IsBDMat (X.map (isoSum hv hδ0)) :=
  isBDMat_map_bdMap _ _ _ X

theorem isoSum_sector {n : ℕ} (X : Mat n (lp E ∞)) (k : ι) :
    (X.map (isoSum hv hδ0)).map (blkL k k) = (X.map (evalHom (A := E) k)).map (v k) :=
  map_bdMap_blk _ _ _ X k

theorem isoSum_upper {n : ℕ} (X : Mat n (lp E ∞)) :
    ‖X.map (isoSum hv hδ0)‖ ≤ (1 + δ) * ‖X‖ := by
  refine norm_le_of_BD (isoSum_isBDMat hv hδ0 X) (mul_nonneg (by linarith) (norm_nonneg X))
    fun k => ?_
  rw [isoSum_sector]
  exact ((hv k).2.2.2.2 n (X.map (evalHom (A := E) k)) 0).2.2.trans
    (mul_le_mul_of_nonneg_left (norm_map_evalHom_le X k) (by linarith))

theorem isoSum_lower (hδ1 : δ < 1) {n : ℕ} (X : Mat n (lp E ∞)) :
    (1 - δ) * ‖X‖ ≤ ‖X.map (isoSum hv hδ0)‖ := by
  have hδ1' : 0 < 1 - δ := by linarith
  have hc : 0 ≤ ‖X.map (isoSum hv hδ0)‖ / (1 - δ) := div_nonneg (norm_nonneg _) hδ1'.le
  have hX : ‖X‖ ≤ ‖X.map (isoSum hv hδ0)‖ / (1 - δ) := norm_le_of_sectors X hc fun k => by
    rw [le_div_iff₀ hδ1', mul_comm]
    have h1 := ((hv k).2.2.2.2 n (X.map (evalHom (A := E) k)) 0).2.1
    have h2 := norm_sector_le (isoSum_isBDMat hv hδ0 X) k
    rw [isoSum_sector] at h2
    exact h1.trans h2
  rw [le_div_iff₀ hδ1'] at hX
  linarith

variable (hsum : IsBlockSumAlg A mul Ak mulk)
include hsum

theorem isoSum_mem (b : lp E ∞) : isoSum hv hδ0 b ∈ A :=
  mem_of_blocks hsum (isoSum_isBD hv hδ0 b) fun k => by
    rw [isoSum_blk, ← (hv k).2.1]; exact LinearMap.mem_range_self _ _

theorem isoSum_mul {n : ℕ} (X Y : Mat n (lp E ∞)) :
    ‖(X * Y).map (isoSum hv hδ0) - matMul mul (X.map (isoSum hv hδ0)) (Y.map (isoSum hv hδ0))‖
      ≤ δ * ‖X‖ * ‖Y‖ := by
  have hXm : ∀ i j, X.map (isoSum hv hδ0) i j ∈ A := fun i j => isoSum_mem hv hδ0 hsum _
  have hYm : ∀ i j, Y.map (isoSum hv hδ0) i j ∈ A := fun i j => isoSum_mem hv hδ0 hsum _
  refine norm_le_of_BD (isBDMat_sub (isoSum_isBDMat hv hδ0 _) (isBDMat_matMul hsum hXm hYm))
    (mul_nonneg (mul_nonneg hδ0 (norm_nonneg X)) (norm_nonneg Y)) fun k => ?_
  have hm : (X * Y).map (evalHom (A := E) k) =
      X.map (evalHom (A := E) k) * Y.map (evalHom (A := E) k) :=
    map_mul (matHom n (evalHom (A := E) k)) X Y
  rw [amp_sub, map_blk_matMul hsum hXm hYm, isoSum_sector, isoSum_sector, isoSum_sector, hm]
  exact ((hv k).2.2.2.2 n _ _).1.trans (real_le2 hδ0 (norm_nonneg _) (norm_nonneg _)
    (norm_map_evalHom_le X k) (norm_map_evalHom_le Y k))

/-- **Coordinatewise extended δ-isomorphisms assemble** into `ℓ^∞(Eₖ) → A`. -/
theorem iso_sum (hδ1 : δ < 1) : IsExtDeltaIsoOntoGen δ A mul (isoSum hv hδ0) := by
  have hδ1' : 0 < 1 - δ := by linarith
  refine ⟨fun b b' h => lp.ext (funext fun k => (hv k).1 ?_), ?_, fun b => ?_, ?_,
    fun n X Y => ⟨isoSum_mul hv hδ0 hsum X Y, isoSum_lower hv hδ0 hδ1 X, isoSum_upper hv hδ0 X⟩⟩
  · have := congrArg (blk k k) h
    rwa [isoSum_blk, isoSum_blk] at this
  · ext x
    refine ⟨?_, fun hx => ?_⟩
    · rintro ⟨b, rfl⟩; exact isoSum_mem hv hδ0 hsum b
    · have hex : ∀ k, ∃ b : E k, v k b = blk k k x := fun k => by
        have := blk_mem_of_mem hsum hx k
        rw [← (hv k).2.1] at this
        exact this
      choose b hb using hex
      have hbb : BddAbove (Set.range fun k => ‖b k‖) := ⟨‖x‖ / (1 - δ), by
        rintro _ ⟨k, rfl⟩
        rw [le_div_iff₀ hδ1', mul_comm]
        exact (isoGen_lower (hv k) (b k)).trans (by rw [hb]; exact norm_blk_le k k x)⟩
      refine ⟨⟨b, memℓp_infty hbb⟩, op_ext fun k l => ?_⟩
      by_cases hkl : k = l
      · subst hkl; rw [isoSum_blk]; exact hb k
      · rw [isoSum_isBD hv hδ0 _ k l hkl, isBD_of_mem hsum hx k l hkl]
  · refine op_ext fun k l => ?_
    by_cases hkl : k = l
    · subst hkl
      rw [isoSum_blk, blk_star, isoSum_blk, lp.star_apply, (hv k).2.2.1,
        ContinuousLinearMap.star_eq_adjoint]
    · rw [isoSum_isBD hv hδ0 _ k l hkl, isBD_star (isoSum_isBD hv hδ0 b) k l hkl]
  · have hBD : IsBD (isoSum hv hδ0 1 - 1) := by
      rw [sub_eq_add_neg, ← neg_one_smul ℂ (1 : lp H 2 →L[ℂ] lp H 2)]
      exact isBD_add (isoSum_isBD hv hδ0 1) (isBD_smul _ isBD_one)
    have e : isoSum hv hδ0 1 - 1 = bdHom (diagBlocks (isoSum hv hδ0 1 - 1)) :=
      (bdOp_diagBlocks hBD).symm
    rw [e, NonUnitalStarAlgHom.norm_map (bdHom (H := H)) bdHom_injective]
    refine lp.norm_le_of_forall_le hδ0 fun k => ?_
    rw [diagBlocks_apply, ← blkL_apply, map_sub, blkL_apply, blkL_apply, isoSum_blk, blk_one_self,
      lp.infty_coeFn_one, Pi.one_apply]
    exact (hv k).2.2.2.1

end Iso

end Cert.KitaevSectorSums
