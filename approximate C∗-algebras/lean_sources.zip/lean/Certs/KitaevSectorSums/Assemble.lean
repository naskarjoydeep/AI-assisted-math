import Certs.KitaevSectorSums.BDMat

/-!
# Assembling sector maps

A uniformly bounded family of linear maps `fₖ : Mₖ → Nₖ` gives `⊕fₖ : ℓ^∞(M) → ℓ^∞(N)`. Composed
with `⊕ : ℓ^∞(B(Hₖ)) → B(⊕ₖ Hₖ)` or with `x ↦ (Pₖ x Pₖ)ₖ`, it gives the maps `v`, `Δ`, `Υ` of
Theorem B, and their sector matrices are those of the `fₖ`.
-/

open scoped ComplexOrder ENNReal InnerProductSpace

set_option linter.unusedSectionVars false

noncomputable section

namespace Cert.KitaevSectorSums

open Cert.KitaevChannels

section LpMap

variable {ι : Type} {M N : ι → Type} [∀ k, NormedAddCommGroup (M k)] [∀ k, NormedSpace ℂ (M k)]
  [∀ k, NormedAddCommGroup (N k)] [∀ k, NormedSpace ℂ (N k)]

/-- `⊕ₖ fₖ : ℓ^∞(M) → ℓ^∞(N)` for a uniformly bounded family. -/
def lpMapL (f : ∀ k, M k →ₗ[ℂ] N k) {c : ℝ} (hc : 0 ≤ c) (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) :
    lp M ∞ →ₗ[ℂ] lp N ∞ where
  toFun b := ⟨fun k => f k (b k), memℓp_infty ⟨c * ‖b‖, by
    rintro _ ⟨k, rfl⟩
    exact (hf k (b k)).trans (mul_le_mul_of_nonneg_left
      (lp.norm_apply_le_norm ENNReal.top_ne_zero b k) hc)⟩⟩
  map_add' b b' := lp.ext (funext fun k => by
    change f k ((b + b' : lp M ∞) k) = ((⟨_, _⟩ : lp N ∞) + ⟨_, _⟩ : lp N ∞) k
    rw [lp.coeFn_add, lp.coeFn_add, Pi.add_apply, Pi.add_apply, map_add])
  map_smul' c' b := lp.ext (funext fun k => by
    change f k ((c' • b : lp M ∞) k) = (c' • (⟨_, _⟩ : lp N ∞) : lp N ∞) k
    rw [lp.coeFn_smul, lp.coeFn_smul, Pi.smul_apply, Pi.smul_apply, map_smul])

theorem lpMapL_apply (f : ∀ k, M k →ₗ[ℂ] N k) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) (b : lp M ∞) (k : ι) : lpMapL f hc hf b k = f k (b k) := rfl

end LpMap

variable {ι : Type} [DecidableEq ι] {H : ι → Type} [∀ k, NormedAddCommGroup (H k)]
  [∀ k, InnerProductSpace ℂ (H k)] [∀ k, CompleteSpace (H k)] [∀ k, Nontrivial (H k)]

/-- `x ↦ (Pₖ x Pₖ)ₖ`, the diagonal blocks, as a linear map into `ℓ^∞(B(Hₖ))`. -/
def diagBlocksL : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] lp (fun k => H k →L[ℂ] H k) ∞ where
  toFun := diagBlocks
  map_add' x y := lp.ext (funext fun k => by
    rw [lp.coeFn_add, Pi.add_apply]
    exact map_add (blkL k k) x y)
  map_smul' c x := lp.ext (funext fun k => by
    rw [lp.coeFn_smul, Pi.smul_apply]
    exact map_smul (blkL k k) c x)

theorem diagBlocksL_apply (x : lp H 2 →L[ℂ] lp H 2) (k : ι) : diagBlocksL x k = blk k k x := rfl

section Sector

variable {E : ι → Type} [∀ k, CStarAlgebra (E k)] [∀ k, PartialOrder (E k)]
  [∀ k, StarOrderedRing (E k)] [∀ k, Nontrivial (E k)]

/-- `b ↦ ⊕ₖ fₖ(bₖ)`, from `ℓ^∞(E)` to `B(⊕ₖ Hₖ)`. -/
def bdMap (f : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) : lp E ∞ →ₗ[ℂ] (lp H 2 →L[ℂ] lp H 2) :=
  (bdHom (H := H)).toAlgHom.toLinearMap ∘ₗ lpMapL f hc hf

theorem blk_bdMap_self (f : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) (b : lp E ∞) (k : ι) :
    blk k k (bdMap f hc hf b) = f k (b k) := blk_bdOp_self _ k

theorem isBD_bdMap (f : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) (b : lp E ∞) : IsBD (bdMap f hc hf b) := isBD_bdOp _

theorem isBDMat_map_bdMap (f : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) {n : ℕ} (X : Mat n (lp E ∞)) :
    IsBDMat (X.map (bdMap f hc hf)) := fun i j => isBD_bdMap f hc hf (X i j)

/-- The `k`-th sector of `X.map (⊕ fₖ)` is `Xᵏ.map fₖ`. -/
theorem map_bdMap_blk (f : ∀ k, E k →ₗ[ℂ] (H k →L[ℂ] H k)) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) {n : ℕ} (X : Mat n (lp E ∞)) (k : ι) :
    (X.map (bdMap f hc hf)).map (blkL k k) = (X.map (evalHom (A := E) k)).map (f k) :=
  CStarMatrix.ext fun i j => blk_bdMap_self f hc hf (X i j) k

/-- `x ↦ (fₖ(Pₖ x Pₖ))ₖ`, from `B(⊕ₖ Hₖ)` to `ℓ^∞(E)`. -/
def sectorMap (f : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] E k) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) : (lp H 2 →L[ℂ] lp H 2) →ₗ[ℂ] lp E ∞ :=
  lpMapL f hc hf ∘ₗ diagBlocksL

theorem sectorMap_apply (f : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] E k) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) (x : lp H 2 →L[ℂ] lp H 2) (k : ι) :
    sectorMap f hc hf x k = f k (blk k k x) := rfl

/-- The `k`-th sector of `X.map (x ↦ (fₖ(Pₖ x Pₖ))ₖ)` is `(X.map Pₖ·Pₖ).map fₖ`. -/
theorem map_sectorMap_eval (f : ∀ k, (H k →L[ℂ] H k) →ₗ[ℂ] E k) {c : ℝ} (hc : 0 ≤ c)
    (hf : ∀ k x, ‖f k x‖ ≤ c * ‖x‖) {n : ℕ} (X : Mat n (lp H 2 →L[ℂ] lp H 2)) (k : ι) :
    (X.map (sectorMap f hc hf)).map (evalHom (A := E) k) = (X.map (blkL k k)).map (f k) :=
  CStarMatrix.ext fun i j => rfl

end Sector

end Cert.KitaevSectorSums
